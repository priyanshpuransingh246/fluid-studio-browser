// ==UserScript==
// @name         Fluid Studio Auto-Browser Engine (v11.0 — ChatGPT v20 + Flow AI v3.0 Complete Engine)
// @version      11.0.0
// @description  Complete Dual-Bot Engine: Bot 1 (ChatGPT Image Bot) + Bot 2 (Flow AI Video Bot v3.0 port with Agent-OFF, Settings Pill, Auto Image Upload & Add-to-Prompt, Strict Composer '→' Send Button, 3-Layer Auto-Verify & Scene-Account Report)!
// ==/UserScript==

(function () {
  'use strict';

  if (window.__FLUID_STUDIO_V11__) {
    return;
  }
  window.__FLUID_STUDIO_V11__ = true;

  if (location.href.includes('android_asset/')) {
    return;
  }

  const bridge = window.AndroidBotBridge || null;

  let botRuntime = {
    running: false,
    botType: 1,
    sourcePdf: 'Script.pdf',
    scenes: [],
    flowSettingsConfigured: false,
    sceneAccountMap: {},
    skippedScenes: []
  };

  function sleep(ms) {
    return new Promise((r) => setTimeout(r, ms));
  }

  function sendHomeLog(msg, statusType) {
    const pillText = document.getElementById('itk-live-pill-text');
    if (pillText) {
      pillText.textContent = msg;
    }
    if (bridge && typeof bridge.postHomeLog === 'function') {
      try {
        bridge.postHomeLog(msg, statusType || 'LIVE');
      } catch (e) {}
    }
    console.log('[FLUID-BOT]', msg);
  }

  function syncActiveSessionIfLoggedIn() {
    const isFlow = location.hostname.includes('labs.google') || location.hostname.includes('flow.google');
    let loggedIn = false;
    if (isFlow) {
      const bodyTxt = ((document.body && document.body.innerText) || '').toLowerCase();
      loggedIn = location.href.includes('/project/') || (bodyTxt.includes('new project') && !bodyTxt.includes('create with google flow'));
    } else {
      loggedIn = Boolean(document.querySelector('#prompt-textarea') || document.querySelector('div.ProseMirror[contenteditable="true"]'));
    }

    if (loggedIn && bridge && typeof bridge.autoSyncActiveAccountCookies === 'function') {
      try {
        bridge.autoSyncActiveAccountCookies(isFlow ? 2 : 1, JSON.stringify(localStorage));
      } catch (e) {}
    }
  }

  setInterval(syncActiveSessionIfLoggedIn, 8000);

  function base64ToFile(dataUrl, filename) {
    const arr = dataUrl.split(',');
    const mimeMatch = arr[0].match(/:(.*?);/);
    const mime = mimeMatch ? mimeMatch[1] : 'image/png';
    const bstr = atob(arr[1] || '');
    let n = bstr.length;
    const u8arr = new Uint8Array(n);
    while (n--) u8arr[n] = bstr.charCodeAt(n);
    return new File([u8arr], filename, { type: mime });
  }

  // ============================================================================
  // PART A — BOT 1: CHATGPT IMAGE BOT ENGINE
  // ============================================================================
  function detectReferenceCharName(imagePrompt) {
    const m = String(imagePrompt || '').match(/USE\s+UPLOADED\s+IMAGE\s+AS\s+([^.\n]+)/i);
    if (!m) return '';
    return m[1].replace(/\([^)]*\)/g, '').trim();
  }

  function clickComposerPlusButton() {
    const plusSelectors = [
      'button[data-testid="composer-plus-btn"]',
      'button[aria-label="Attach files"]',
      'button[aria-label*="Add" i][aria-haspopup="menu"]'
    ];
    for (const sel of plusSelectors) {
      const btn = document.querySelector(sel);
      if (btn) {
        btn.click();
        return true;
      }
    }
    const box = document.querySelector('#prompt-textarea') || document.querySelector('[contenteditable="true"]');
    if (!box) return false;
    const bRect = box.getBoundingClientRect();
    const btns = Array.from(document.querySelectorAll('button, [role="button"]')).filter((b) => {
      const r = b.getBoundingClientRect();
      return (
        r.width >= 20 && r.width <= 60 &&
        r.height >= 20 && r.height <= 60 &&
        Math.abs(r.top - bRect.top) < 65 &&
        r.left <= bRect.left + 55 &&
        r.left >= bRect.left - 80
      );
    }).sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left);
    if (btns.length > 0) {
      btns[0].click();
      return true;
    }
    return false;
  }

  async function attachReferenceImageToChatGpt(charName) {
    if (!bridge || typeof bridge.findReferenceImageJson !== 'function') return false;
    let refObj = null;
    try {
      const raw = bridge.findReferenceImageJson(charName);
      if (raw) refObj = JSON.parse(raw);
    } catch (e) {}

    if (!refObj || !refObj.found || !refObj.base64) {
      sendHomeLog('[Note] Reference character "' + charName + '" ki image folder me nahi mili, prompt bina image ke bhej rhe h.', 'WARN');
      return false;
    }

    const fileObj = base64ToFile(refObj.base64, refObj.fileName || (charName + '.png'));
    const fileInput = document.querySelector('input[type="file"]');
    if (fileInput) {
      const dt = new DataTransfer();
      dt.items.add(fileObj);
      fileInput.files = dt.files;
      fileInput.dispatchEvent(new Event('change', { bubbles: true }));
      await sleep(3200);
      return true;
    }

    if (clickComposerPlusButton()) {
      await sleep(900);
      const fi2 = document.querySelector('input[type="file"]');
      if (fi2) {
        const dt = new DataTransfer();
        dt.items.add(fileObj);
        fi2.files = dt.files;
        fi2.dispatchEvent(new Event('change', { bubbles: true }));
        await sleep(3200);
        return true;
      }
    }
    return false;
  }

  function getLatestAssistantText() {
    const turns = document.querySelectorAll('[data-message-author-role="assistant"], article');
    if (turns.length > 0) {
      const lastTurn = turns[turns.length - 1];
      return (lastTurn.innerText || '').toLowerCase();
    }
    const mainEl = document.querySelector('main') || document.body;
    const full = (mainEl ? mainEl.innerText || '' : '').toLowerCase();
    return full.slice(-1200);
  }

  function checkChatGptLimitReached() {
    const limitPhrases = [
      'reached your image generation limit',
      'reached your image creation limit',
      "you've hit the free plan limit for image",
      'hit the free plan limit for image',
      "you've reached your limit for image",
      'wait before generating more images',
      'too many requests in 1 hour',
      "you've reached the current usage cap",
      'resets in ',
      'limit resets'
    ];
    const recentText = getLatestAssistantText();
    return limitPhrases.some((p) => recentText.includes(p));
  }

  function checkChatGptRefusal() {
    if (checkChatGptLimitReached()) return '';
    const recentText = getLatestAssistantText();
    if (recentText.includes('creating image')) return '';
    const refusalMap = {
      'content policy': 'ChatGPT Content Guideline Refusal',
      'against our policies': 'ChatGPT Guideline Refusal',
      'i cannot generate': 'ChatGPT Declined Image Generation',
      "i can't generate": 'ChatGPT Declined Image Generation',
      "i'm unable to generate": 'ChatGPT Unable to Generate Image',
      'i am unable to generate': 'ChatGPT Unable to Generate Image',
      "i can't create images": 'ChatGPT Declined Image Creation',
      'unable to create this image': 'ChatGPT Unable to Create Image'
    };
    for (const phrase of Object.keys(refusalMap)) {
      if (recentText.includes(phrase)) return refusalMap[phrase];
    }
    return '';
  }

  function isStillCreatingImage() {
    const stopBtn = document.querySelector(
      'button[data-testid="stop-button"], button[aria-label*="Stop streaming" i], button[aria-label*="Stop generating" i]'
    );
    return Boolean(stopBtn);
  }

  function getLargeAssistantImages() {
    const rawImgs = Array.from(
      document.querySelectorAll('[data-message-author-role="assistant"] img, article img, main img')
    );
    const seen = new Set();
    const list = [];

    for (const img of rawImgs) {
      if (seen.has(img)) continue;
      seen.add(img);

      if (img.closest('[data-message-author-role="user"]')) continue;
      if (img.closest('#itk-bottom-bar') || img.closest('nav') || img.closest('aside') || img.closest('header')) continue;

      if (img.getAttribute('aria-hidden') === 'true') continue;
      const st = (img.getAttribute('style') || '').toLowerCase();
      const cl = (typeof img.className === 'string' ? img.className : '').toLowerCase();
      if (st.includes('blur(') || cl.includes('blur-')) continue;

      const src = img.currentSrc || img.src || '';
      const sLower = src.toLowerCase();
      if (!src || sLower.startsWith('data:image/svg') || sLower.includes('avatars') || sLower.includes('gravatar') || sLower.includes('lh3.googleusercontent.com')) {
        continue;
      }

      const rect = img.getBoundingClientRect ? img.getBoundingClientRect() : { width: 0, height: 0 };
      const w = Math.max(img.naturalWidth || 0, img.width || 0, Math.round(rect.width || 0));
      const h = Math.max(img.naturalHeight || 0, img.height || 0, Math.round(rect.height || 0));

      if (img.complete && w >= 200 && h >= 200) {
        list.push({
          el: img,
          src: src,
          w: w,
          h: h
        });
      }
    }
    return list;
  }

  async function downloadAndSaveCreatedImage(sceneNo, imgObj) {
    if (!imgObj || (!imgObj.el && !imgObj.src)) return false;
    const imgUrl = imgObj.src;
    const imgEl = imgObj.el;

    if (bridge && typeof bridge.setActiveDownloadSceneNo === 'function') {
      bridge.setActiveDownloadSceneNo(sceneNo);
    }

    // TARIKA 1: Direct HTML5 Offscreen Canvas
    if (imgEl && imgEl.complete && (imgEl.naturalWidth >= 200 || imgEl.width >= 200)) {
      try {
        const canvas = document.createElement('canvas');
        canvas.width = imgEl.naturalWidth || imgEl.width || 1024;
        canvas.height = imgEl.naturalHeight || imgEl.height || 1024;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(imgEl, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/png');
        if (dataUrl && dataUrl.length > 12000 && bridge && typeof bridge.saveSceneImageToOutputFolder === 'function') {
          const saved = bridge.saveSceneImageToOutputFolder(sceneNo, dataUrl);
          if (saved && !saved.startsWith('ERROR:')) {
            return true;
          }
        }
      } catch (e) {}
    }

    // TARIKA 2: Authenticated Fetch
    if (imgUrl && (imgUrl.startsWith('http') || imgUrl.startsWith('blob:'))) {
      try {
        const resp = await fetch(imgUrl, { credentials: 'include' });
        if (resp.ok) {
          const blob = await resp.blob();
          if (blob && blob.size > 10000) {
            const b64Data = await new Promise((resolve) => {
              const reader = new FileReader();
              reader.onloadend = () => resolve(reader.result);
              reader.onerror = () => resolve(null);
              reader.readAsDataURL(blob);
            });
            if (b64Data && bridge && typeof bridge.saveSceneImageToOutputFolder === 'function') {
              const saved = bridge.saveSceneImageToOutputFolder(sceneNo, b64Data);
              if (saved && !saved.startsWith('ERROR:')) {
                return true;
              }
            }
          }
        }
      } catch (e) {}
    }

    // TARIKA 3: Native Android Java Cookie-Authenticated Downloader
    if (imgUrl && imgUrl.startsWith('http') && bridge && typeof bridge.downloadImageUrlToOutputFolder === 'function') {
      try {
        const saved = bridge.downloadImageUrlToOutputFolder(sceneNo, imgUrl, location.href);
        if (saved && !saved.startsWith('ERROR:')) {
          return true;
        }
      } catch (e) {}
    }

    // TARIKA 4: Lightbox Click -> Download Button
    if (imgEl) {
      try {
        imgEl.click();
        await sleep(1000);
        const btns = Array.from(document.querySelectorAll('button, a, [role="button"]'));
        for (const b of btns) {
          const r = b.getBoundingClientRect();
          if (r.width === 0 || r.height === 0) continue;
          const label = (b.getAttribute('aria-label') || b.getAttribute('title') || '').toLowerCase();
          if (label.includes('download')) {
            b.click();
            await sleep(2500);
            break;
          }
        }
        document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true }));
        await sleep(400);
        if (bridge && typeof bridge.doesSceneImageExist === 'function' && bridge.doesSceneImageExist(sceneNo)) {
          return true;
        }
      } catch (e) {}
    }

    return false;
  }

  async function dismissPopupsIfAny() {
    const buttons = Array.from(document.querySelectorAll('button'));
    for (const b of buttons) {
      const txt = (b.innerText || '').trim().toLowerCase();
      if (txt === 'stay logged in' || txt === 'okay' || txt === 'dismiss' || txt === 'continue') {
        try { b.click(); await sleep(300); } catch (e) {}
      }
    }
  }

  function findChatGptPromptBox() {
    return (
      document.querySelector('div#prompt-textarea[contenteditable="true"]') ||
      document.querySelector('#prompt-textarea') ||
      document.querySelector('div.ProseMirror[contenteditable="true"]') ||
      document.querySelector('textarea[placeholder]') ||
      document.querySelector('[contenteditable="true"]')
    );
  }

  function isLoginWallVisible() {
    const loginBtn = document.querySelector(
      'button[data-testid="login-button"], button[data-testid="welcome-login-button"], a[href*="/auth/login"]'
    );
    return Boolean(loginBtn);
  }

  async function waitForPromptBoxWithoutDroppingScene(sPad) {
    let notifiedWait = false;
    while (botRuntime.running) {
      await dismissPopupsIfAny();
      const box = findChatGptPromptBox();
      if (box && !isLoginWallVisible()) {
        if (notifiedWait) {
          sendHomeLog('✅ ChatGPT prompt box mil gya! Scene ' + sPad + ' ab bheja jaa rha h...', 'ok');
          syncActiveSessionIfLoggedIn();
        }
        return box;
      }

      if (!notifiedWait) {
        notifiedWait = true;
        sendHomeLog(
          '⏳ Scene ' + sPad + ': ChatGPT load ya login ka wait ho rha h (Koi bhi scene drop nahi hoga — agar login mang rha h toh upar Chatgpt tab me login karein)...',
          'warn'
        );
      }
      await sleep(1500);
    }
    return null;
  }

  async function typeAndSendPromptInSameChat(sPad, promptText, charRefName) {
    const box = await waitForPromptBoxWithoutDroppingScene(sPad);
    if (!box || !botRuntime.running) {
      return null;
    }

    if (charRefName) {
      await attachReferenceImageToChatGpt(charRefName);
    }

    const activeBox = findChatGptPromptBox() || box;
    activeBox.focus();

    if (activeBox.tagName === 'TEXTAREA') {
      activeBox.value = promptText;
      activeBox.dispatchEvent(new Event('input', { bubbles: true }));
    } else {
      activeBox.innerHTML = '<p>' + promptText.replace(/</g, '&lt;').replace(/>/g, '&gt;') + '</p>';
      activeBox.dispatchEvent(new InputEvent('input', { bubbles: true, data: promptText }));
    }
    await sleep(300);

    const beforeImgs = getLargeAssistantImages();
    const prevImgCount = beforeImgs.length;
    const prevSrcSet = new Set(beforeImgs.map((i) => i.src));

    const sendSelectors = [
      'button[data-testid="send-button"]',
      'button[aria-label*="Send prompt" i]',
      'button[aria-label*="Send" i]',
      'form button[type="submit"]'
    ];

    let sent = false;
    for (let attempt = 0; attempt < 12; attempt++) {
      for (const sel of sendSelectors) {
        const sBtn = document.querySelector(sel);
        if (sBtn && !sBtn.disabled) {
          sBtn.click();
          sent = true;
          break;
        }
      }
      if (sent) break;
      await sleep(250);
    }

    if (!sent) {
      activeBox.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true }));
    }

    return { prevImgCount, prevSrcSet };
  }

  async function runSingleChatGptScene(scene) {
    const sNo = Number(scene.scene_no);
    const sPad = String(sNo).padStart(2, '0');

    if (bridge && typeof bridge.doesSceneImageExist === 'function' && bridge.doesSceneImageExist(sNo)) {
      sendHomeLog('scene' + sPad + ' ki image pehle se output_images folder me hai (Scene_' + sPad + '.png) — skip kar rhe h.', 'ok');
      return 'done';
    }

    const readyBox = await waitForPromptBoxWithoutDroppingScene(sPad);
    if (!readyBox || !botRuntime.running) return 'stopped';

    const charRefName = detectReferenceCharName(scene.image_prompt);

    sendHomeLog('Chatgpt me scene' + sPad + ' ka prompt likha jaa rha h ....', 'LIVE');

    const fullPrompt = 'Create an image: ' + scene.image_prompt;
    const snap = await typeAndSendPromptInSameChat(sPad, fullPrompt, charRefName);
    if (!snap) return 'stopped';

    sendHomeLog(
      'Chatgpt me scene' + sPad + ' ka prompt ko send kar diya gya h ab wait kar rhe h image generate karne ka aur phir download kare ....',
      'LIVE'
    );

    await sleep(2500);

    let lastCandidateSrc = '';
    let stableCount = 0;

    for (let tick = 1; tick <= 160; tick++) {
      if (!botRuntime.running) return 'stopped';

      if (checkChatGptLimitReached()) {
        return 'rate_limit';
      }

      const refusal = checkChatGptRefusal();
      if (refusal) {
        sendHomeLog('⚠️ Scene ' + sPad + ' skipped (' + refusal + '). Agle scene par badh rhe h...', 'warn');
        return 'refused';
      }

      const currImgs = getLargeAssistantImages();
      const newImgs = currImgs.filter((item) => !snap.prevSrcSet.has(item.src));
      const hasNewImage = newImgs.length > 0 || currImgs.length > snap.prevImgCount;

      if (hasNewImage) {
        const candidate = newImgs.length > 0 ? newImgs[newImgs.length - 1] : currImgs[currImgs.length - 1];
        if (candidate && candidate.src) {
          if (candidate.src === lastCandidateSrc) {
            stableCount += 1;
          } else {
            lastCandidateSrc = candidate.src;
            stableCount = 1;
          }

          if (!isStillCreatingImage() || stableCount >= 2) {
            await sleep(700);
            const refreshed = getLargeAssistantImages();
            const refreshedNew = refreshed.filter((item) => !snap.prevSrcSet.has(item.src));
            const finalImgObj = refreshedNew.length > 0
              ? refreshedNew[refreshedNew.length - 1]
              : (refreshed.length > 0 ? refreshed[refreshed.length - 1] : candidate);

            const savedOk = await downloadAndSaveCreatedImage(sNo, finalImgObj);
            if (savedOk) {
              sendHomeLog('scene' + sPad + ' ki image download ho gyi h (output_images/Scene_' + sPad + '.png)', 'ok');
              return 'done';
            }
          }
        }
      }

      await sleep(1500);
    }

    sendHomeLog('⚠️ Scene ' + sPad + ' timeout ho gya. Agle scene par badh rhe h...', 'err');
    return 'timeout';
  }

  // ============================================================================
  // PART B — BOT 2: FLOW AI VIDEO BOT ENGINE (EXACT PORT OF `flow_video_bot.py` v3.0)
  // ============================================================================

  // 1. Flow AI Login & Popup Helper (No malformed ServiceLogin URLs, normal screen size!)
  function setupFlowPageEnvironmentAndLoginHelper() {
    const isFlowHost = location.hostname.includes('labs.google') || location.hostname.includes('flow.google');
    if (!isFlowHost) return;

    // Intercept window.open & target="_blank" so OAuth popups always open in the current tab
    try {
      window.open = function (u) {
        if (u && typeof u === 'string' && u !== 'about:blank') {
          window.location.href = u;
          return window;
        }
        return {
          closed: false,
          focus: function () {},
          close: function () {},
          location: {
            set href(v) { if (v && v !== 'about:blank') window.location.href = v; },
            get href() { return window.location.href; },
            assign: function (v) { if (v) window.location.href = v; },
            replace: function (v) { if (v) window.location.replace(v); }
          }
        };
      };
    } catch (e) {}

    document.addEventListener('click', function (ev) {
      const el = ev.target && ev.target.closest ? ev.target.closest('button, a, [role="button"]') : null;
      if (!el) return;
      if (el.tagName === 'A' && el.hasAttribute('target')) {
        el.removeAttribute('target');
      }
      const txt = (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim().toLowerCase();
      if (txt.includes('create with google flow') || txt === 'create with flow' || txt === 'sign in') {
        try {
          sessionStorage.setItem('itk_flow_create_clicked_ts', String(Date.now()));
        } catch (e) {}
      }
    }, true);

    // If the user clicked "Create with Google Flow" and it bounced back within 5s without opening Google Login,
    // open plain https://accounts.google.com/ (which NEVER gives a 400 error, and auto-returns to Flow after sign-in!)
    setTimeout(() => {
      if (location.href.includes('/project/')) return;
      const allBtns = Array.from(document.querySelectorAll('button, a, [role="button"]'));
      const createBtn = allBtns.find((b) => {
        const t = (b.innerText || b.textContent || '').replace(/\s+/g, ' ').trim().toLowerCase();
        return t.includes('create with google flow');
      });
      if (!createBtn) return;

      let clickedTs = 0;
      try {
        clickedTs = Number(sessionStorage.getItem('itk_flow_create_clicked_ts') || 0);
      } catch (e) {}

      if (clickedTs > 0 && (Date.now() - clickedTs) < 5500) {
        try {
          sessionStorage.removeItem('itk_flow_create_clicked_ts');
        } catch (e) {}
        sendHomeLog('Opening Google Account Sign-In...', 'LIVE');
        location.href = 'https://accounts.google.com/';
      }
    }, 900);
  }

  setupFlowPageEnvironmentAndLoginHelper();

  function dispatchRealClick(el, customX, customY) {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    const cx = customX !== undefined ? customX : (r.left + r.width / 2);
    const cy = customY !== undefined ? customY : (r.top + r.height / 2);
    const opts = { bubbles: true, cancelable: true, view: window, clientX: cx, clientY: cy, button: 0, buttons: 1 };
    try {
      el.dispatchEvent(new PointerEvent('pointerdown', opts));
      el.dispatchEvent(new MouseEvent('mousedown', opts));
      el.dispatchEvent(new PointerEvent('pointerup', opts));
      el.dispatchEvent(new MouseEvent('mouseup', opts));
      el.dispatchEvent(new MouseEvent('click', opts));
    } catch (e) {}
    try {
      el.click();
    } catch (e) {}
    return true;
  }

  function dismissAllFlowPopupsOnce() {
    // 1. Check specifically for "Did you request help signing in?" security callout cards (Click X, NEVER Review)
    const allContainers = Array.from(document.querySelectorAll('div, section, aside, [role="dialog"], [role="alert"], [role="region"], dialog'));
    for (const box of allContainers) {
      const r = box.getBoundingClientRect();
      if (r.width < 140 || r.height < 55 || r.width > 750 || r.height > 520) continue;
      const boxTxt = (box.innerText || '').toLowerCase();
      if (
        boxTxt.includes('did you request help signing in') ||
        boxTxt.includes('request to help you sign in') ||
        boxTxt.includes('review the request')
      ) {
        const candidates = Array.from(box.querySelectorAll('button, [role="button"], a, span, div'));
        for (const c of candidates) {
          const cr = c.getBoundingClientRect();
          if (cr.width === 0 || cr.height === 0 || cr.width > 55 || cr.height > 55) continue;
          const cTxt = (c.innerText || c.textContent || '').trim().toLowerCase();
          const cAria = (c.getAttribute('aria-label') || c.getAttribute('title') || '').trim().toLowerCase();
          if (cTxt.includes('review') || cAria.includes('review')) continue;
          if (['x', '✕', '✖', '×', '⨯', 'close'].includes(cTxt) || cAria.includes('close') || cAria.includes('dismiss')) {
            dispatchRealClick(c);
            return 'security-alert-close';
          }
        }
      }
    }

    // 2. Check small '✕' / '×' close buttons inside top-right notification callouts
    const allClickable = Array.from(document.querySelectorAll('button, [role="button"], a, div[tabindex="0"], span[role="button"]'));
    for (const el of allClickable) {
      const r = el.getBoundingClientRect();
      if (r.width === 0 || r.height === 0 || r.width > 52 || r.height > 52) continue;
      const txt = (el.innerText || el.textContent || '').trim().toLowerCase();
      const aria = (el.getAttribute('aria-label') || el.getAttribute('title') || '').trim().toLowerCase();
      if (txt.includes('review') || aria.includes('review')) continue;
      const isExplicitX = ['x', '✕', '✖', '×', '⨯'].includes(txt) || aria.includes('close') || aria.includes('dismiss');
      if (isExplicitX && r.left > window.innerWidth * 0.55 && r.top < 360) {
        dispatchRealClick(el);
        return 'top-right-callout-x';
      }
    }

    // 3. Standard consent / welcome buttons
    const dismissWords = ['okay', 'ok', 'got it', 'i understand', 'agree', 'i agree', 'accept', 'continue', 'skip', 'dismiss', 'no thanks'];
    for (const el of allClickable) {
      const rect = el.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) continue;
      const txt = (el.innerText || el.textContent || '').trim().toLowerCase();
      const aria = (el.getAttribute('aria-label') || el.getAttribute('title') || '').trim().toLowerCase();
      if (txt === 'review' || aria.includes('review')) continue;
      if (dismissWords.includes(txt) || dismissWords.includes(aria)) {
        dispatchRealClick(el);
        return 'popup:' + (txt || aria);
      }
    }

    // 4. Standard modal dialogs
    const dialogs = Array.from(document.querySelectorAll('[role="dialog"], dialog, [aria-modal="true"]'));
    for (const d of dialogs) {
      if (d.offsetParent === null) continue;
      const btns = Array.from(d.querySelectorAll('button, [role="button"]'));
      for (const b of btns) {
        const t = (b.innerText || '').trim().toLowerCase();
        const a = (b.getAttribute('aria-label') || '').trim().toLowerCase();
        if (t.includes('review') || a.includes('review')) continue;
        if (['x', '✕', '✖', '×', 'close'].includes(t) || a.includes('close') || a.includes('dismiss')) {
          dispatchRealClick(b);
          return 'dialog-x';
        }
      }
    }
    return null;
  }

  async function dismissAllFlowPopups() {
    for (let i = 0; i < 4; i++) {
      const closed = dismissAllFlowPopupsOnce();
      if (closed) {
        await sleep(650);
      } else {
        break;
      }
    }
  }

  async function enterFlowProject() {
    await dismissAllFlowPopups();
    if (location.href.includes('/project/')) return true;

    sendHomeLog('Flow AI me "+ New project" khola jaa rha h...', 'LIVE');
    for (let attempt = 0; attempt < 5; attempt++) {
      if (location.href.includes('/project/')) return true;
      await dismissAllFlowPopups();

      const els = Array.from(document.querySelectorAll('button, a, [role="button"], div, span'));
      let clicked = false;
      for (const el of els) {
        const r = el.getBoundingClientRect();
        if (r.width < 50 || r.width > 420 || r.height < 20 || r.height > 100) continue;
        if (r.top < 0 || r.top > window.innerHeight) continue;
        const txt = (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim().toLowerCase();
        if (
          txt === 'new project' ||
          txt === '+ new project' ||
          txt === 'add new project' ||
          txt.endsWith('new project') ||
          txt === 'create with flow' ||
          txt === 'create with google flow'
        ) {
          el.scrollIntoView({ block: 'center' });
          await sleep(200);
          dispatchRealClick(el);
          clicked = true;
          break;
        }
      }

      for (let w = 0; w < 12; w++) {
        if (location.href.includes('/project/')) return true;
        await sleep(500);
      }
    }
    await sleep(1500);
    await dismissAllFlowPopups();
    return location.href.includes('/project/');
  }

  function findFlowAgentButton() {
    const btns = Array.from(document.querySelectorAll('button, [role="button"]'));
    return btns.find((b) => {
      const r = b.getBoundingClientRect();
      const txt = (b.innerText || b.textContent || '').trim().toLowerCase();
      return r.height > 0 && r.top > window.innerHeight * 0.40 && (txt === 'agent' || txt.endsWith('agent'));
    }) || null;
  }

  function findFlowComposerBox(agentBtn) {
    if (!agentBtn) return null;
    let composerBox = agentBtn.parentElement;
    while (composerBox && composerBox !== document.body) {
      const cr = composerBox.getBoundingClientRect();
      if (cr.width >= Math.min(260, window.innerWidth * 0.55) && cr.width <= window.innerWidth * 0.96 && cr.height >= 50) {
        return composerBox;
      }
      composerBox = composerBox.parentElement;
    }
    return null;
  }

  async function ensureFlowAgentModeOff() {
    const agentBtn = findFlowAgentButton();
    if (!agentBtn) return;

    const ariaPressed = agentBtn.getAttribute('aria-pressed');
    const dataState = agentBtn.getAttribute('data-state');
    const ariaSelected = agentBtn.getAttribute('aria-selected');
    const bg = window.getComputedStyle(agentBtn).backgroundColor || '';
    let isBrightBg = false;
    const m = bg.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
    if (m) {
      const r = parseInt(m[1], 10), g = parseInt(m[2], 10), b = parseInt(m[3], 10);
      if (r > 120 || g > 120 || b > 120) isBrightBg = true;
    }

    if (ariaPressed === 'true' || dataState === 'on' || dataState === 'active' || ariaSelected === 'true' || isBrightBg) {
      dispatchRealClick(agentBtn);
      sendHomeLog('Flow AI: Agent Mode ON tha -> OFF kar diya gya.', 'LIVE');
      await sleep(1200);
    }
  }

  function clickFlowPopoverOption(targets) {
    const lowerTargets = targets.map((t) => t.toLowerCase());
    const els = Array.from(document.querySelectorAll('button, [role="button"], [role="tab"], [role="option"], [role="radio"], [role="menuitem"], div, span'));
    for (const target of lowerTargets) {
      for (const el of els) {
        const r = el.getBoundingClientRect();
        if (r.width === 0 || r.height === 0 || r.width > 300 || r.height > 80) continue;
        if (r.top < window.innerHeight * 0.12 || r.top > window.innerHeight * 0.92) continue;
        const txt = (el.innerText || el.textContent || '').trim().toLowerCase();
        if (txt === target) {
          dispatchRealClick(el);
          return txt;
        }
      }
    }
    return null;
  }

  async function configureFlowSettingsPopover() {
    const btns = Array.from(document.querySelectorAll('button, [role="button"]'));
    const agentBtn = findFlowAgentButton();

    if (agentBtn) {
      const composerBox = findFlowComposerBox(agentBtn);
      const maxRight = composerBox
        ? composerBox.getBoundingClientRect().right + 18
        : window.innerWidth * 0.92;

      const aRect = agentBtn.getBoundingClientRect();
      const rightBtns = btns.filter((b) => {
        if (b === agentBtn) return false;
        const r = b.getBoundingClientRect();
        return (
          r.width > 0 && r.height > 0 &&
          Math.abs(r.top - aRect.top) < 42 &&
          r.left > aRect.right - 4 &&
          r.right <= maxRight
        );
      }).sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left);

      const pillByText = rightBtns.find((b) => {
        const t = (b.innerText || '').toLowerCase();
        return t.includes('video') || t.includes('720p') || t.includes('1080p') || t.includes('6s') || t.includes('x1') || t.includes('16:9') || b.getBoundingClientRect().width >= 60;
      });
      if (pillByText) {
        dispatchRealClick(pillByText);
      } else if (rightBtns.length >= 2) {
        dispatchRealClick(rightBtns[0]);
      } else if (rightBtns.length === 1) {
        dispatchRealClick(rightBtns[0]);
      }
    }

    await sleep(1500);
    if (clickFlowPopoverOption(['video'])) await sleep(800);
    if (clickFlowPopoverOption(['16:9'])) await sleep(450);

    const bodyTxt = (document.body.innerText || '').toLowerCase();
    if (!bodyTxt.includes('omni 3.1 flash') && !bodyTxt.includes('omni flash')) {
      clickFlowPopoverOption(['veo 2', 'veo 3', 'veo', 'veo 3.1', 'nano banana 2.1', 'imagen']);
      await sleep(700);
      clickFlowPopoverOption(['omni 3.1 flash', 'omni flash']);
    }
    if (clickFlowPopoverOption(['720p'])) await sleep(450);
    if (clickFlowPopoverOption(['6s', '6 sec', '6 seconds'])) await sleep(450);
    if (clickFlowPopoverOption(['x1'])) await sleep(450);

    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true }));
    await sleep(700);
  }

  function getFlowRemainingCredits() {
    const els = Array.from(document.querySelectorAll('button, span, div, a, p'));
    for (const el of els) {
      if (el.children.length > 2) continue;
      const r = el.getBoundingClientRect();
      if (r.width === 0 || r.height === 0) continue;
      const txt = (el.innerText || el.textContent || '').trim();
      if (!txt || txt.length > 45) continue;
      const aria = (el.getAttribute('aria-label') || el.getAttribute('title') || '').trim();
      const combined = (txt + ' ' + aria).toLowerCase();
      let m = combined.match(/(\d[\d,]*)\s*credits?(?:\s+left|\s+remaining)?/i);
      if (!m) m = combined.match(/credits?\s*[:\-]?\s*(\d[\d,]*)/i);
      if (m) {
        const num = parseInt(m[1].replace(/,/g, ''), 10);
        if (!isNaN(num) && num >= 0 && num <= 500000) return num;
      }
    }
    return null;
  }

  function countFlowProjectCards() {
    const maxTop = window.innerHeight * 0.72;
    const seenRects = [];
    const candidates = Array.from(document.querySelectorAll('video, canvas, img, [data-testid*="card"], [class*="card"]'));
    for (const el of candidates) {
      const r = el.getBoundingClientRect();
      if (r.width < 120 || r.height < 70) continue;
      if (r.top < 35 || r.top > maxTop) continue;
      const isDup = seenRects.some((sr) => Math.abs(sr.left - r.left) < 25 && Math.abs(sr.top - r.top) < 25);
      if (!isDup) seenRects.push({ left: r.left, top: r.top, width: r.width, height: r.height });
    }
    return seenRects.length;
  }

  function checkFlowCreditsExhausted() {
    const exhaustedPhrases = [
      'not enough credits',
      'insufficient credits',
      'out of credits',
      'no credits left',
      'no credits remaining',
      "you don't have enough credits",
      'monthly limit reached',
      'daily limit reached',
      'quota exceeded'
    ];
    const alerts = Array.from(document.querySelectorAll('[role="alert"], [role="status"], .snackbar, .toast, dialog, [role="dialog"]'));
    for (const a of alerts) {
      const txt = (a.innerText || '').toLowerCase();
      if (txt.includes('running low')) continue;
      if (exhaustedPhrases.some((p) => txt.includes(p))) return true;
    }
    const rem = getFlowRemainingCredits();
    if (rem !== null && rem === 0) return true;
    return false;
  }

  function checkFlowGenerationError() {
    if (checkFlowCreditsExhausted()) return '';
    const errorPairs = [
      ['violat', 'Flow AI Policy Violation (Prompt / Image Restricted)'],
      ['policy', 'Flow AI Policy Violation / Guideline Restriction'],
      ['guidelines', 'Flow AI Policy Violation / Guideline Restriction'],
      ['try a different prompt', 'Flow AI Rejected Video Prompt (Policy Violation)'],
      ['try another prompt', 'Flow AI Rejected Video Prompt (Policy Violation)'],
      ['try a different image', 'Flow AI Rejected Uploaded Image'],
      ['try another image', 'Flow AI Rejected Uploaded Image'],
      ['cannot upload', 'Flow AI Image Upload Rejected'],
      ['upload failed', 'Flow AI Image Upload Failed'],
      ["couldn't upload", 'Flow AI Image Upload Rejected'],
      ['unable to upload', 'Flow AI Image Upload Rejected'],
      ["couldn't generate", 'Flow AI Could Not Generate Video (Policy / Error)'],
      ['unable to generate', 'Flow AI Unable to Generate Video (Policy / Error)'],
      ['failed to generate', 'Flow AI Failed to Generate Video'],
      ['generation failed', 'Flow AI Generation Failed'],
      ["can't create", 'Flow AI Declined Video Creation (Policy / Error)'],
      ['cannot create', 'Flow AI Declined Video Creation (Policy / Error)'],
      ['something went wrong', 'Flow AI Generation Error'],
      ['blocked', 'Flow AI Blocked Generation (Safety Filter)'],
      ['filtered', 'Flow AI Filtered Generation (Safety Policy)']
    ];

    const containers = Array.from(document.querySelectorAll('[role="alert"], [role="status"], .snackbar, .toast, [role="dialog"], dialog'));
    const textBlocks = Array.from(document.querySelectorAll('div, span, p')).filter((el) => {
      if (el.children.length > 2) return false;
      const r = el.getBoundingClientRect();
      return r.width > 40 && r.height > 12 && r.height < 140;
    });

    for (const el of [...containers, ...textBlocks]) {
      const txt = (el.innerText || el.textContent || '').trim().toLowerCase();
      if (!txt || txt.length > 350) continue;
      if (txt.includes('running low') || txt.includes('did you request help signing in') || txt.includes('request to help you sign in')) continue;
      for (const [phrase, reason] of errorPairs) {
        if (txt.includes(phrase)) return reason;
      }
    }
    return '';
  }

  async function clearFailedFlowPromptAndPopups() {
    await dismissAllFlowPopups();
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true }));
    await sleep(400);

    const btns = Array.from(document.querySelectorAll('button, [role="button"]'));
    for (const b of btns) {
      const r = b.getBoundingClientRect();
      if (r.top < window.innerHeight * 0.45 || r.width === 0 || r.height === 0) continue;
      const aria = (b.getAttribute('aria-label') || b.getAttribute('title') || '').toLowerCase();
      const txt = (b.innerText || '').trim().toLowerCase();
      if (aria.includes('remove') || aria.includes('delete') || aria.includes('clear') || txt === 'x' || txt === '✕' || txt === '×' || txt === 'close') {
        if (r.width <= 44 && r.height <= 44) {
          dispatchRealClick(b);
        }
      }
    }
  }

  function clickTopRightAddMediaPlusButton() {
    dismissAllFlowPopupsOnce();
    const btns = Array.from(document.querySelectorAll('button, [role="button"]')).filter((b) => {
      const r = b.getBoundingClientRect();
      const txt = (b.innerText || b.textContent || '').trim().toLowerCase();
      const aria = (b.getAttribute('aria-label') || b.getAttribute('title') || '').trim().toLowerCase();
      if (
        txt.includes('review') || aria.includes('review') ||
        txt.includes('sign in') || aria.includes('sign in') ||
        ['x', '✕', '✖', '×', 'close', 'dismiss'].includes(txt) ||
        aria.includes('close') || aria.includes('dismiss')
      ) {
        return false;
      }
      return (
        r.width >= 22 && r.width <= 95 &&
        r.height >= 22 && r.height <= 75 &&
        r.top >= 10 && r.top <= 260 &&
        r.left > window.innerWidth * 0.55 &&
        r.left < window.innerWidth * 0.92
      );
    });
    if (btns.length === 0) return false;
    btns.sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left);
    dispatchRealClick(btns[0]);
    return true;
  }

  function clickPromptBarPlusIcon() {
    const btns = Array.from(document.querySelectorAll('button, [role="button"]'));
    const agentBtn = findFlowAgentButton();
    if (agentBtn) {
      const aRect = agentBtn.getBoundingClientRect();
      const leftBtns = btns.filter((b) => {
        if (b === agentBtn) return false;
        const r = b.getBoundingClientRect();
        return r.width > 0 && r.height > 0 && Math.abs(r.top - aRect.top) < 40 && r.left < aRect.left && (aRect.left - r.left) < 135;
      }).sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left);
      if (leftBtns.length > 0) {
        dispatchRealClick(leftBtns[leftBtns.length - 1]);
        return true;
      }
    }
    return false;
  }

  async function uploadAndAttachFlowSceneImage(sceneNo) {
    const sPad = String(sceneNo).padStart(2, '0');
    const imgFilename = 'Scene_' + sPad + '.png';
    const imgStem = 'Scene_' + sPad;

    let b64Data = '';
    if (bridge && typeof bridge.getSceneImageBase64 === 'function') {
      b64Data = bridge.getSceneImageBase64(sceneNo);
    }
    if (!b64Data || !b64Data.startsWith('data:image')) {
      sendHomeLog('⚠️ Scene_' + sPad + '.png output_images folder me nahi mili!', 'warn');
      return false;
    }

    // Arm Native onShowFileChooser auto-responder AND prepare JS File object
    if (bridge && typeof bridge.setPendingAutoUploadSceneImage === 'function') {
      bridge.setPendingAutoUploadSceneImage(sceneNo);
    }
    const fileObj = base64ToFile(b64Data, imgFilename);

    let uploaded = false;

    // Strategy 1: Top-Right '+' (Add media) -> 'Upload' (Exact match with flow_video_bot.py Step A)
    if (clickTopRightAddMediaPlusButton()) {
      await sleep(1300);
      const menuItems = Array.from(document.querySelectorAll('[role="menuitem"], button, li, div[role="button"], span'));
      const uploadItem = menuItems.find((el) => {
        const r = el.getBoundingClientRect();
        const t = (el.innerText || el.textContent || '').trim().toLowerCase();
        return r.width > 0 && r.height > 0 && r.height < 75 && (t === 'upload' || t.startsWith('upload'));
      });
      if (uploadItem) {
        if (bridge && typeof bridge.setPendingAutoUploadSceneImage === 'function') {
          bridge.setPendingAutoUploadSceneImage(sceneNo);
        }
        dispatchRealClick(uploadItem);
        await sleep(800);
        const fi = document.querySelector('input[type="file"]');
        if (fi && (!fi.files || fi.files.length === 0)) {
          try {
            const dt = new DataTransfer();
            dt.items.add(fileObj);
            fi.files = dt.files;
            fi.dispatchEvent(new Event('change', { bubbles: true }));
          } catch (e) {}
        }
        uploaded = true;
      }
    }

    // Strategy 2: Bottom-Left '+' -> 'Upload media' fallback
    if (!uploaded) {
      document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true }));
      await sleep(400);
      if (clickPromptBarPlusIcon()) {
        await sleep(1300);
        const els = Array.from(document.querySelectorAll('button, [role="button"], [role="menuitem"], span, div'));
        const upMediaBtn = els.find((el) => {
          const r = el.getBoundingClientRect();
          const t = (el.innerText || el.textContent || '').trim().toLowerCase();
          return r.width > 0 && r.height > 0 && r.height < 75 && (t === 'upload media' || t === 'upload');
        });
        if (upMediaBtn) {
          if (bridge && typeof bridge.setPendingAutoUploadSceneImage === 'function') {
            bridge.setPendingAutoUploadSceneImage(sceneNo);
          }
          dispatchRealClick(upMediaBtn);
          await sleep(800);
          uploaded = true;
        }
        const fi2 = document.querySelector('input[type="file"]');
        if (fi2 && (!fi2.files || fi2.files.length === 0)) {
          try {
            const dt = new DataTransfer();
            dt.items.add(fileObj);
            fi2.files = dt.files;
            fi2.dispatchEvent(new Event('change', { bubbles: true }));
            uploaded = true;
          } catch (e) {}
        }
      }
    }

    // Strategy 3: Direct <input type="file"> injection if present
    if (!uploaded) {
      const directInput = document.querySelector('input[type="file"]');
      if (directInput) {
        try {
          const dt = new DataTransfer();
          dt.items.add(fileObj);
          directInput.files = dt.files;
          directInput.dispatchEvent(new Event('change', { bubbles: true }));
          uploaded = true;
        } catch (e) {}
      }
    }

    // Close any lingering Top-Right '+' dropdown menu ('Upload / New collection / Create character')
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true }));

    // Step B: Wait for image upload (20% -> 60% -> 100%) to complete
    await sleep(3200);
    for (let w = 0; w < 28; w++) {
      if (checkFlowGenerationError()) return false;
      const stillUp = Array.from(document.querySelectorAll('div, span')).some((el) => {
        if (el.children.length > 0) return false;
        return /^\d{1,2}%$/.test((el.innerText || '').trim());
      });
      if (!stillUp) break;
      await sleep(1600);
    }
    await sleep(2200);

    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true }));
    await sleep(400);

    // Step C: Open '+' asset menu, search 'Scene_XX', select card, and click 'Add to prompt'
    for (let attempt = 0; attempt < 3; attempt++) {
      let searchBox = document.querySelector('input[placeholder*="Search assets" i]');
      if (!searchBox || searchBox.getBoundingClientRect().width === 0) {
        clickPromptBarPlusIcon();
        await sleep(1600);
        searchBox = document.querySelector('input[placeholder*="Search assets" i]');
      }

      if (searchBox && searchBox.getBoundingClientRect().width > 0) {
        dispatchRealClick(searchBox);
        searchBox.focus();
        await sleep(250);
        try {
          const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
          nativeInputValueSetter.call(searchBox, imgStem);
        } catch (e) {
          searchBox.value = imgStem;
        }
        searchBox.dispatchEvent(new InputEvent('input', { bubbles: true, data: imgStem }));
        searchBox.dispatchEvent(new Event('change', { bubbles: true }));
        await sleep(1400);
      }

      const allEls = Array.from(document.querySelectorAll('div, button, li, [role="option"], [role="menuitem"], [role="button"]'));
      for (const el of allEls) {
        const r = el.getBoundingClientRect();
        if (r.width < 55 || r.height < 22 || r.height > 95) continue;
        const txt = (el.innerText || '').trim().toLowerCase();
        if (txt.includes(imgFilename.toLowerCase()) || txt.includes(imgStem.toLowerCase())) {
          dispatchRealClick(el);
          break;
        }
      }
      await sleep(1200);

      const addBtn = Array.from(document.querySelectorAll('button, [role="button"], div, span')).find((b) => {
        const r = b.getBoundingClientRect();
        return r.width > 0 && r.height > 0 && r.height <= 80 && (b.innerText || b.textContent || '').trim().toLowerCase() === 'add to prompt';
      });
      if (addBtn) {
        dispatchRealClick(addBtn);
        await sleep(1600);
        return true;
      }
      await sleep(1200);
    }
    return true;
  }

  // Exact port of `_find_and_click_composer_send_button` from flow_video_bot.py v3.0!
  function findAndClickFlowComposerSendButton() {
    const btns = Array.from(document.querySelectorAll('button, [role="button"]'));
    const agentBtn = findFlowAgentButton();
    if (!agentBtn) return false;

    const aRect = agentBtn.getBoundingClientRect();
    const composerBox = findFlowComposerBox(agentBtn);

    const composerRightLimit = composerBox
      ? Math.min(composerBox.getBoundingClientRect().right + 18, window.innerWidth * 0.94)
      : window.innerWidth * 0.86;

    const rowRightBtns = btns.filter((b) => {
      if (b === agentBtn) return false;
      const r = b.getBoundingClientRect();
      if (r.width < 18 || r.height < 18 || r.width > 260 || r.height > 70) return false;
      if (Math.abs((r.top + r.height / 2) - (aRect.top + aRect.height / 2)) > 38) return false;
      if (r.left <= aRect.right - 4) return false;
      if (r.right > composerRightLimit) return false;
      if (composerBox && !composerBox.contains(b)) return false;
      return true;
    }).sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left);

    const settingsPill = rowRightBtns.find((b) => {
      const t = (b.innerText || b.textContent || '').toLowerCase();
      return (
        t.includes('video') || t.includes('720p') || t.includes('1080p') ||
        t.includes('6s') || t.includes('5s') || t.includes('8s') ||
        t.includes('x1') || t.includes('16:9') || b.getBoundingClientRect().width >= 65
      );
    });

    let sendBtn = null;
    if (settingsPill) {
      const pRect = settingsPill.getBoundingClientRect();
      const afterPill = rowRightBtns.filter((b) => {
        if (b === settingsPill) return false;
        const r = b.getBoundingClientRect();
        return r.left >= pRect.right - 6 && r.left <= pRect.right + 90 && r.width <= 68;
      });
      if (afterPill.length > 0) sendBtn = afterPill[0];
    }

    if (!sendBtn && rowRightBtns.length > 0) {
      sendBtn = rowRightBtns[rowRightBtns.length - 1];
    }

    if (sendBtn) {
      dispatchRealClick(sendBtn);
      return true;
    }

    // Fallback: click 24px to the right of the Settings Pill
    if (settingsPill) {
      const pr = settingsPill.getBoundingClientRect();
      const tx = pr.right + 24;
      const ty = pr.top + pr.height / 2;
      const elAtPoint = document.elementFromPoint(tx, ty);
      if (elAtPoint) {
        const btnAtPoint = elAtPoint.closest('button, [role="button"]') || elAtPoint;
        dispatchRealClick(btnAtPoint, tx, ty);
        return true;
      }
    }
    return false;
  }

  function isFlowPromptStillInComposer(videoPrompt) {
    const snippet = String(videoPrompt || '').trim().slice(0, 28).toLowerCase();
    if (!snippet) return false;
    const els = Array.from(document.querySelectorAll('textarea, [contenteditable="true"], [role="textbox"], div, p, span'));
    for (const el of els) {
      const r = el.getBoundingClientRect();
      if (r.top < window.innerHeight * 0.45 || r.width === 0 || r.height === 0) continue;
      if (r.right > window.innerWidth * 0.92) continue;
      const txt = (el.innerText || el.value || el.textContent || '').trim().toLowerCase();
      if (txt.includes(snippet)) return true;
    }
    return false;
  }

  async function typeFlowPromptAndClickSend(videoPrompt) {
    // 1. Close asset search popover or any open dropdown menu first
    const searchBox = document.querySelector('input[placeholder*="Search assets" i]');
    if (searchBox && searchBox.getBoundingClientRect().width > 0) {
      const addBtn = Array.from(document.querySelectorAll('button, [role="button"]')).find(
        (b) => (b.innerText || '').trim().toLowerCase() === 'add to prompt' && b.getBoundingClientRect().width > 0
      );
      if (addBtn) dispatchRealClick(addBtn);
      else document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true }));
      await sleep(900);
    }

    const hasOpenMenu = Array.from(document.querySelectorAll('[role="menu"], [role="listbox"]')).some((m) => {
      const r = m.getBoundingClientRect();
      return r.width > 50 && r.height > 50;
    });
    if (hasOpenMenu) {
      document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true }));
      await sleep(450);
    }

    // 2. Focus 'What do you want to create?' prompt box inside the composer
    const els = Array.from(document.querySelectorAll('textarea, [contenteditable="true"], [role="textbox"], div, span'));
    let box = els.find((el) => {
      const r = el.getBoundingClientRect();
      if (r.width === 0 || r.height === 0 || r.top < window.innerHeight * 0.45) return false;
      if (r.right > window.innerWidth * 0.92) return false;
      const ph = (el.getAttribute('placeholder') || el.getAttribute('data-placeholder') || el.innerText || '').toLowerCase();
      return ph.includes('what do you want to create');
    });

    if (!box) {
      box = Array.from(document.querySelectorAll('textarea, [contenteditable="true"], [role="textbox"]')).find((el) => {
        const r = el.getBoundingClientRect();
        return r.width > 0 && r.height > 0 && r.top >= window.innerHeight * 0.45;
      });
    }

    if (!box) throw new Error('Flow AI prompt box nahi mila');

    dispatchRealClick(box);
    box.focus();
    await sleep(300);

    // 3. Type videoPrompt using execCommand + native setter + InputEvent so Flow AI enables the Send button!
    let insertedViaExec = false;
    try {
      document.execCommand('selectAll', false, null);
      document.execCommand('delete', false, null);
      insertedViaExec = document.execCommand('insertText', false, videoPrompt);
    } catch (e) {}

    if (!insertedViaExec) {
      if (box.tagName === 'TEXTAREA' || box.tagName === 'INPUT') {
        try {
          const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
          setter.call(box, videoPrompt);
        } catch (e) {
          box.value = videoPrompt;
        }
      } else {
        box.textContent = videoPrompt;
      }
    }

    box.dispatchEvent(new InputEvent('input', { bubbles: true, cancelable: true, data: videoPrompt }));
    box.dispatchEvent(new Event('change', { bubbles: true }));
    await sleep(1000);

    // 4. Click the round '→' Send button strictly inside the composer bar
    if (!findAndClickFlowComposerSendButton()) {
      box.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true }));
    }

    // 5. Verify after 2.5s that the prompt was submitted (composer box cleared)
    await sleep(2500);
    if (isFlowPromptStillInComposer(videoPrompt)) {
      document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true }));
      await sleep(350);
      findAndClickFlowComposerSendButton();
      await sleep(800);
      if (isFlowPromptStillInComposer(videoPrompt)) {
        box.focus();
        box.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true }));
      }
    }
  }

  function writeRealtimeFlowReport() {
    if (!bridge || typeof bridge.saveFlowSceneAccountReport !== 'function') return;
    const completedNums = Object.keys(botRuntime.sceneAccountMap).map(Number).sort((a, b) => a - b);
    const droppedNums = botRuntime.skippedScenes.map((x) => x.scene_no).sort((a, b) => a - b);

    const accountsSummary = {};
    completedNums.forEach((sNo) => {
      const acc = botRuntime.sceneAccountMap[sNo];
      if (!accountsSummary[acc]) accountsSummary[acc] = [];
      accountsSummary[acc].push('Scene_' + String(sNo).padStart(2, '0'));
    });

    const lines = [
      '==========================================================================',
      '   ITIHASKAR SAMAY - SCENE & ACCOUNT STATUS REPORT (FLOW AI BOT v3.0)',
      '==========================================================================',
      'PDF / Source File          : ' + (botRuntime.sourcePdf || 'Script.pdf'),
      'Date & Time                : ' + new Date().toLocaleString(),
      'Total Scenes Selected      : ' + botRuntime.scenes.length + ' -> [' + botRuntime.scenes.map((s) => s.scene_no).join(', ') + ']',
      'Total Scenes BANE (YES)    : ' + completedNums.length + ' -> [' + completedNums.join(', ') + ']',
      'Total Scenes NAHI BANE (NO): ' + droppedNums.length + ' -> [' + droppedNums.join(', ') + ']',
      '--------------------------------------------------------------------------',
      '   ACCOUNT-WISE SUMMARY (KIS ACCOUNT MEIN KON-KON SA SCENE BANA):',
      '--------------------------------------------------------------------------'
    ];

    const accKeys = Object.keys(accountsSummary);
    if (accKeys.length > 0) {
      accKeys.forEach((accName) => {
        const list = accountsSummary[accName];
        lines.push('   * ' + accName + ' : ' + list.length + ' Videos -> ' + list.join(', '));
      });
    } else {
      lines.push('   * Abhi tak kisi account mein is batch ka video nahi bana.');
    }

    lines.push(
      '',
      '--------------------------------------------------------------------------',
      '   SCENE-BY-SCENE TABLE (SCENE BANA YA NAHI + KIS ACCOUNT MEIN BANA):',
      '--------------------------------------------------------------------------'
    );

    botRuntime.scenes.forEach((s) => {
      const sNo = s.scene_no;
      const sPad = String(sNo).padStart(2, '0');
      if (botRuntime.sceneAccountMap[sNo]) {
        lines.push('   Scene_' + sPad + ' | Haan Bana (YES) | Account: ' + botRuntime.sceneAccountMap[sNo] + ' | Image: Scene_' + sPad + '.png (Verified Created)');
      } else {
        const sk = botRuntime.skippedScenes.find((x) => x.scene_no === sNo);
        if (sk) {
          lines.push('   Scene_' + sPad + ' | Nahi Bana (NO)  | Account: --- | ' + sk.reason);
        } else {
          lines.push('   Scene_' + sPad + ' | Pending...      | Account: --- | Waiting to process');
        }
      }
    });

    if (botRuntime.skippedScenes.length > 0) {
      lines.push(
        '',
        '--------------------------------------------------------------------------',
        '   DROPPED / POLICY ERROR SCENES KE VIDEO PROMPTS (JO NAHI BANE):',
        '--------------------------------------------------------------------------'
      );
      botRuntime.skippedScenes.forEach((item) => {
        const sPad = String(item.scene_no).padStart(2, '0');
        lines.push(
          '\n[Scene_' + sPad + ' | Image: Scene_' + sPad + '.png] -> NAHI BANA (NO)\n' +
          '   Reason       : ' + item.reason + '\n' +
          '   Video Prompt : ' + (item.video_prompt || '')
        );
      });
    }

    lines.push('==========================================================================\n');
    bridge.saveFlowSceneAccountReport(botRuntime.sourcePdf || 'Flow_Scenes.pdf', lines.join('\n'));
  }

  async function runSingleFlowVideoScene(scene) {
    const sNo = Number(scene.scene_no);
    const sPad = String(sNo).padStart(2, '0');
    const accLabel = (bridge && typeof bridge.getActiveAccountLabel === 'function')
      ? bridge.getActiveAccountLabel(2)
      : 'Flow_Account_1';

    await enterFlowProject();
    if (checkFlowCreditsExhausted()) return 'rate_limit';

    await ensureFlowAgentModeOff();
    if (!botRuntime.flowSettingsConfigured) {
      await configureFlowSettingsPopover();
      botRuntime.flowSettingsConfigured = true;
    }

    sendHomeLog('Flow AI me Scene_' + sPad + '.png upload ho rha h aur video prompt likha jaa rha h ....', 'LIVE');
    const attached = await uploadAndAttachFlowSceneImage(sNo);
    const upErr = checkFlowGenerationError();
    if (!attached || upErr) {
      const reason = upErr || 'Image upload ya Add to prompt reject ho gaya';
      botRuntime.skippedScenes.push({ scene_no: sNo, reason: reason, video_prompt: scene.video_prompt });
      await clearFailedFlowPromptAndPopups();
      writeRealtimeFlowReport();
      sendHomeLog('⚠️ Flow AI Scene ' + sPad + ' dropped (' + reason + '). Moving to next scene...', 'warn');
      return 'refused';
    }

    const creditsBefore = getFlowRemainingCredits();
    const cardsBefore = countFlowProjectCards();

    await typeFlowPromptAndClickSend(scene.video_prompt || scene.image_prompt);
    sendHomeLog(
      'Flow AI me scene' + sPad + ' ka video prompt send kar diya gya h, ab video generate hone ka wait kar rhe h ....',
      'LIVE'
    );

    await sleep(5500);
    if (checkFlowCreditsExhausted()) return 'rate_limit';

    let detectedErr = '';
    let sawRendering = false;

    for (let tick = 1; tick <= 42; tick++) {
      if (!botRuntime.running) return 'stopped';
      if (checkFlowCreditsExhausted()) return 'rate_limit';

      const errNow = checkFlowGenerationError();
      if (errNow) {
        detectedErr = errNow;
        break;
      }

      const stillRendering = Array.from(document.querySelectorAll('div, span, p')).some((el) => {
        if (el.children.length > 0) return false;
        const txt = (el.innerText || '').trim().toLowerCase();
        return /^\d{1,2}%$/.test(txt) || txt === 'generating...' || txt === 'creating...' || txt === 'rendering...';
      });

      if (stillRendering) sawRendering = true;
      if (sawRendering && !stillRendering && tick >= 3) break;
      if (!sawRendering && !stillRendering && tick >= 9) break;
      await sleep(3800);
    }

    if (checkFlowCreditsExhausted()) return 'rate_limit';
    await sleep(2000);
    if (!detectedErr) detectedErr = checkFlowGenerationError();

    const creditsAfter = getFlowRemainingCredits();
    const cardsAfter = countFlowProjectCards();

    let videoCreated = false;
    let failReason = detectedErr;

    if (detectedErr) {
      videoCreated = false;
    } else if (creditsBefore !== null && creditsAfter !== null) {
      if (creditsAfter < creditsBefore) videoCreated = true;
      else if (creditsAfter === creditsBefore && cardsAfter <= cardsBefore) {
        videoCreated = false;
        failReason = 'Video nahi bana (Credits kam nahi huye / Policy Error se reject hua)';
      } else {
        videoCreated = true;
      }
    } else {
      if (cardsAfter > cardsBefore || sawRendering) videoCreated = true;
      else {
        videoCreated = false;
        failReason = 'Video nahi bana (Na rendering chali aur na naya video card aaya)';
      }
    }

    if (videoCreated) {
      botRuntime.sceneAccountMap[sNo] = accLabel;
      writeRealtimeFlowReport();
      sendHomeLog('✅ scene' + sPad + ' ka video Flow AI me ban gya h! (' + accLabel + ')', 'ok');
      return 'done';
    } else {
      await clearFailedFlowPromptAndPopups();
      botRuntime.skippedScenes.push({ scene_no: sNo, reason: failReason || 'Policy Error', video_prompt: scene.video_prompt });
      writeRealtimeFlowReport();
      sendHomeLog('⚠️ Flow AI scene' + sPad + ' nahi bana (' + (failReason || 'Policy Error') + '). Agle scene par badh rhe h...', 'warn');
      return 'refused';
    }
  }

  // ============================================================================
  // MASTER AUTOMATION LOOP (HANDLES BOTH BOT 1 CHATGPT & BOT 2 FLOW AI)
  // ============================================================================
  async function runAutomationQueueLoop() {
    if (botRuntime.running) return;

    if (!bridge || typeof bridge.getActiveAutomationQueueJson !== 'function') return;
    let queueObj = null;
    try {
      const raw = bridge.getActiveAutomationQueueJson();
      if (raw && raw.length > 5) queueObj = JSON.parse(raw);
    } catch (e) {}

    if (!queueObj || !queueObj.active || !Array.isArray(queueObj.scenes) || queueObj.scenes.length === 0) {
      return;
    }

    const isFlowPage = location.hostname.includes('labs.google') || location.hostname.includes('flow.google');
    const qBotType = Number(queueObj.botType || 1);
    if ((qBotType === 2 && !isFlowPage) || (qBotType === 1 && isFlowPage)) {
      return;
    }

    botRuntime.running = true;
    botRuntime.botType = qBotType;
    botRuntime.sourcePdf = queueObj.sourcePdf || 'Script.pdf';
    botRuntime.scenes = queueObj.scenes;

    await sleep(1000);

    for (let i = 0; i < botRuntime.scenes.length; i++) {
      if (!botRuntime.running) break;
      const scene = botRuntime.scenes[i];
      if (scene.status === 'done') continue;

      let result = 'error';
      try {
        result = (botRuntime.botType === 2)
          ? await runSingleFlowVideoScene(scene)
          : await runSingleChatGptScene(scene);
      } catch (err) {
        sendHomeLog('Scene ' + scene.scene_no + ' Note: ' + err.message + ' — retrying in 2s...', 'warn');
        await sleep(2000);
        i -= 1;
        continue;
      }

      if (result === 'stopped') {
        break;
      }

      if (result === 'rate_limit') {
        botRuntime.running = false;
        sendHomeLog('⚠️ Is account me limit/credits khatam ho gye h! Next account apne aap login kiya jaa rha h...', 'warn');
        if (bridge && typeof bridge.switchToNextAccountOnLimit === 'function') {
          const sw = bridge.switchToNextAccountOnLimit(botRuntime.botType);
          if (sw === 'NO_MORE_ACCOUNTS') {
            sendHomeLog('🛑 Saare saved accounts ki limit khatam ho chuki h! Home page se Option 3 (Limits Reset) chunein.', 'BATCH_DONE');
            if (bridge.clearActiveAutomationQueue) bridge.clearActiveAutomationQueue();
          }
        }
        return;
      }

      if (result === 'done' || result === 'refused' || result === 'timeout') {
        scene.status = 'done';
        if (bridge && typeof bridge.updateActiveAutomationQueueJson === 'function') {
          bridge.updateActiveAutomationQueueJson(JSON.stringify(queueObj));
        }
      }

      await sleep(700);
    }

    if (botRuntime.running) {
      botRuntime.running = false;
      if (bridge && typeof bridge.clearActiveAutomationQueue === 'function') {
        bridge.clearActiveAutomationQueue();
      }
      if (botRuntime.botType === 2) {
        writeRealtimeFlowReport();
        sendHomeLog('🎉 Flow AI ke saare requested scenes process ho gye aur Report scene_account_reports folder me save ho gyi!', 'BATCH_DONE');
      } else {
        sendHomeLog('🎉 Saare requested scenes ki images download ho kar output_images folder me save ho gyi hain!', 'BATCH_DONE');
      }
    }
  }

  window.__ITK_START_QUEUE_NOW__ = function () {
    runAutomationQueueLoop();
  };

  window.__ITK_STOP_QUEUE_NOW__ = function () {
    botRuntime.running = false;
  };

  function mountMinimalBottomStatusPill() {
    if (document.getElementById('itk-bottom-bar') || !document.body) return;
    const bar = document.createElement('div');
    bar.id = 'itk-bottom-bar';
    bar.style.cssText =
      'position:fixed;bottom:8px;right:8px;z-index:2147483640;background:rgba(13,17,23,0.92);border:1px solid rgba(255,138,31,0.45);border-radius:999px;padding:5px 12px;color:#a7f3d0;font-family:ui-monospace,monospace;font-size:11px;box-shadow:0 6px 20px rgba(0,0,0,0.6);pointer-events:none;max-width:92vw;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;';
    bar.innerHTML = '<span style="color:#ff8a1f;font-weight:700;">⚡ Fluid Studio: </span><span id="itk-live-pill-text">Ready</span>';
    document.body.appendChild(bar);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', mountMinimalBottomStatusPill);
  } else {
    mountMinimalBottomStatusPill();
  }

  setTimeout(() => {
    if (bridge && typeof bridge.isAutomationCurrentlyActive === 'function' && bridge.isAutomationCurrentlyActive()) {
      runAutomationQueueLoop();
    }
  }, 1200);
})();
