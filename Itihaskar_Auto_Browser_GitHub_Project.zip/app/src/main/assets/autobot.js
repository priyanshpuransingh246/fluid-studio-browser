// ==UserScript==
// @name         Fluid Studio Auto-Browser Engine (v11.0 — ChatGPT v20 + Flow AI v3.0 Complete Engine)
// @version      11.0.0
// @description  Complete Dual-Bot Engine: Bot 1 (ChatGPT Image Bot) + Bot 2 (Flow AI Video Bot v3.0 port with Agent-OFF, Settings Pill, Auto Image Upload & Add-to-Prompt, Strict Composer '→' Send Button, 3-Layer Auto-Verify & Scene-Account Report)!
// ==/UserScript==

(function () {
  'use strict';

  if (window.__FLUID_STUDIO_V12_ACTIVE__) {
    return;
  }
  window.__FLUID_STUDIO_V12_ACTIVE__ = true;

  if (location.href.includes('android_asset/')) {
    return;
  }

  const bridge = window.AndroidBotBridge || null;

  let botRuntime = {
    running: false,
    botType: 1,
    sourcePdf: 'Script.pdf',
    scenes: [],
    flowSettingsConfigured: false,
    sceneAccountMap: {},
    skippedScenes: []
  };

  function sleep(ms) {
    return new Promise((r) => setTimeout(r, ms));
  }

  function sendHomeLog(msg, statusType) {
    const pillText = document.getElementById('itk-live-pill-text');
    if (pillText) {
      pillText.textContent = msg;
    }
    if (bridge && typeof bridge.postHomeLog === 'function') {
      try {
        bridge.postHomeLog(msg, statusType || 'LIVE');
      } catch (e) {}
    }
    console.log('[FLUID-BOT]', msg);
  }

  function syncActiveSessionIfLoggedIn() {
    const isFlow = location.hostname.includes('labs.google') || location.hostname.includes('flow.google');
    let loggedIn = false;
    if (isFlow) {
      const bodyTxt = ((document.body && document.body.innerText) || '').toLowerCase();
      loggedIn = location.href.includes('/project/') || (bodyTxt.includes('new project') && !bodyTxt.includes('create with google flow'));
    } else {
      loggedIn = Boolean(document.querySelector('#prompt-textarea') || document.querySelector('div.ProseMirror[contenteditable="true"]'));
    }

    if (loggedIn && bridge && typeof bridge.autoSyncActiveAccountCookies === 'function') {
      try {
        bridge.autoSyncActiveAccountCookies(isFlow ? 2 : 1, JSON.stringify(localStorage));
      } catch (e) {}
    }
  }

  setInterval(syncActiveSessionIfLoggedIn, 8000);

  function base64ToFile(dataUrl, filename) {
    const arr = dataUrl.split(',');
    const mimeMatch = arr[0].match(/:(.*?);/);
    const mime = mimeMatch ? mimeMatch[1] : 'image/png';
    const bstr = atob(arr[1] || '');
    let n = bstr.length;
    const u8arr = new Uint8Array(n);
    while (n--) u8arr[n] = bstr.charCodeAt(n);
    return new File([u8arr], filename, { type: mime });
  }

  // ============================================================================
  // PART A — BOT 1: CHATGPT IMAGE BOT ENGINE
  // ============================================================================
  function detectReferenceCharName(imagePrompt) {
    const m = String(imagePrompt || '').match(/USE\s+UPLOADED\s+IMAGE\s+AS\s+([^.\n]+)/i);
    if (!m) return '';
    return m[1].replace(/\([^)]*\)/g, '').trim();
  }

  function clickComposerPlusButton() {
    const plusSelectors = [
      'button[data-testid="composer-plus-btn"]',
      'button[aria-label="Attach files"]',
      'button[aria-label*="Add" i][aria-haspopup="menu"]'
    ];
    for (const sel of plusSelectors) {
      const btn = document.querySelector(sel);
      if (btn) {
        btn.click();
        return true;
      }
    }
    const box = document.querySelector('#prompt-textarea') || document.querySelector('[contenteditable="true"]');
    if (!box) return false;
    const bRect = box.getBoundingClientRect();
    const btns = Array.from(document.querySelectorAll('button, [role="button"]')).filter((b) => {
      const r = b.getBoundingClientRect();
      return (
        r.width >= 20 && r.width <= 60 &&
        r.height >= 20 && r.height <= 60 &&
        Math.abs(r.top - bRect.top) < 65 &&
        r.left <= bRect.left + 55 &&
        r.left >= bRect.left - 80
      );
    }).sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left);
    if (btns.length > 0) {
      btns[0].click();
      return true;
    }
    return false;
  }

  async function attachReferenceImageToChatGpt(charName) {
    if (!bridge || typeof bridge.findReferenceImageJson !== 'function') return false;
    let refObj = null;
    try {
      const raw = bridge.findReferenceImageJson(charName);
      if (raw) refObj = JSON.parse(raw);
    } catch (e) {}

    if (!refObj || !refObj.found || !refObj.base64) {
      sendHomeLog('[Note] Reference character "' + charName + '" ki image folder me nahi mili, prompt bina image ke bhej rhe h.', 'WARN');
      return false;
    }

    const fileObj = base64ToFile(refObj.base64, refObj.fileName || (charName + '.png'));
    const fileInput = document.querySelector('input[type="file"]');
    if (fileInput) {
      const dt = new DataTransfer();
      dt.items.add(fileObj);
      fileInput.files = dt.files;
      fileInput.dispatchEvent(new Event('change', { bubbles: true }));
      await sleep(3200);
      return true;
    }

    if (clickComposerPlusButton()) {
      await sleep(900);
      const fi2 = document.querySelector('input[type="file"]');
      if (fi2) {
        const dt = new DataTransfer();
        dt.items.add(fileObj);
        fi2.files = dt.files;
        fi2.dispatchEvent(new Event('change', { bubbles: true }));
        await sleep(3200);
        return true;
      }
    }
    return false;
  }

  function getLatestAssistantText() {
    const turns = document.querySelectorAll('[data-message-author-role="assistant"], article');
    if (turns.length > 0) {
      const lastTurn = turns[turns.length - 1];
      return (lastTurn.innerText || '').toLowerCase();
    }
    const mainEl = document.querySelector('main') || document.body;
    const full = (mainEl ? mainEl.innerText || '' : '').toLowerCase();
    return full.slice(-1200);
  }

  function checkChatGptLimitReached() {
    const limitPhrases = [
      'reached your image generation limit',
      'reached your image creation limit',
      "you've hit the free plan limit for image",
      'hit the free plan limit for image',
      "you've reached your limit for image",
      'wait before generating more images',
      'too many requests in 1 hour',
      "you've reached the current usage cap",
      'resets in ',
      'limit resets'
    ];
    const recentText = getLatestAssistantText();
    return limitPhrases.some((p) => recentText.includes(p));
  }

  function checkChatGptRefusal() {
    if (checkChatGptLimitReached()) return '';
    const recentText = getLatestAssistantText();
    if (recentText.includes('creating image')) return '';
    const refusalMap = {
      'content policy': 'ChatGPT Content Guideline Refusal',
      'against our policies': 'ChatGPT Guideline Refusal',
      'i cannot generate': 'ChatGPT Declined Image Generation',
      "i can't generate": 'ChatGPT Declined Image Generation',
      "i'm unable to generate": 'ChatGPT Unable to Generate Image',
      'i am unable to generate': 'ChatGPT Unable to Generate Image',
      "i can't create images": 'ChatGPT Declined Image Creation',
      'unable to create this image': 'ChatGPT Unable to Create Image'
    };
    for (const phrase of Object.keys(refusalMap)) {
      if (recentText.includes(phrase)) return refusalMap[phrase];
    }
    return '';
  }

  function isStillCreatingImage() {
    const stopBtn = document.querySelector(
      'button[data-testid="stop-button"], button[aria-label*="Stop streaming" i], button[aria-label*="Stop generating" i]'
    );
    return Boolean(stopBtn);
  }

  function getLargeAssistantImages() {
    const rawImgs = Array.from(
      document.querySelectorAll('[data-message-author-role="assistant"] img, article img, main img')
    );
    const seen = new Set();
    const list = [];

    for (const img of rawImgs) {
      if (seen.has(img)) continue;
      seen.add(img);

      if (img.closest('[data-message-author-role="user"]')) continue;
      if (img.closest('#itk-bottom-bar') || img.closest('nav') || img.closest('aside') || img.closest('header')) continue;

      if (img.getAttribute('aria-hidden') === 'true') continue;
      const st = (img.getAttribute('style') || '').toLowerCase();
      const cl = (typeof img.className === 'string' ? img.className : '').toLowerCase();
      if (st.includes('blur(') || cl.includes('blur-')) continue;

      const src = img.currentSrc || img.src || '';
      const sLower = src.toLowerCase();
      if (!src || sLower.startsWith('data:image/svg') || sLower.includes('avatars') || sLower.includes('gravatar') || sLower.includes('lh3.googleusercontent.com')) {
        continue;
      }

      const rect = img.getBoundingClientRect ? img.getBoundingClientRect() : { width: 0, height: 0 };
      const w = Math.max(img.naturalWidth || 0, img.width || 0, Math.round(rect.width || 0));
      const h = Math.max(img.naturalHeight || 0, img.height || 0, Math.round(rect.height || 0));

      if (img.complete && w >= 200 && h >= 200) {
        list.push({
          el: img,
          src: src,
          w: w,
          h: h
        });
      }
    }
    return list;
  }

  async function downloadAndSaveCreatedImage(sceneNo, imgObj) {
    if (!imgObj || (!imgObj.el && !imgObj.src)) return false;
    const imgUrl = imgObj.src;
    const imgEl = imgObj.el;

    if (bridge && typeof bridge.setActiveDownloadSceneNo === 'function') {
      bridge.setActiveDownloadSceneNo(sceneNo);
    }

    // TARIKA 1: Direct HTML5 Offscreen Canvas
    if (imgEl && imgEl.complete && (imgEl.naturalWidth >= 200 || imgEl.width >= 200)) {
      try {
        const canvas = document.createElement('canvas');
        canvas.width = imgEl.naturalWidth || imgEl.width || 1024;
        canvas.height = imgEl.naturalHeight || imgEl.height || 1024;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(imgEl, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/png');
        if (dataUrl && dataUrl.length > 12000 && bridge && typeof bridge.saveSceneImageToOutputFolder === 'function') {
          const saved = bridge.saveSceneImageToOutputFolder(sceneNo, dataUrl);
          if (saved && !saved.startsWith('ERROR:')) {
            return true;
          }
        }
      } catch (e) {}
    }

    // TARIKA 2: Authenticated Fetch
    if (imgUrl && (imgUrl.startsWith('http') || imgUrl.startsWith('blob:'))) {
      try {
        const resp = await fetch(imgUrl, { credentials: 'include' });
        if (resp.ok) {
          const blob = await resp.blob();
          if (blob && blob.size > 10000) {
            const b64Data = await new Promise((resolve) => {
              const reader = new FileReader();
              reader.onloadend = () => resolve(reader.result);
              reader.onerror = () => resolve(null);
              reader.readAsDataURL(blob);
            });
            if (b64Data && bridge && typeof bridge.saveSceneImageToOutputFolder === 'function') {
              const saved = bridge.saveSceneImageToOutputFolder(sceneNo, b64Data);
              if (saved && !saved.startsWith('ERROR:')) {
                return true;
              }
            }
          }
        }
      } catch (e) {}
    }

    // TARIKA 3: Native Android Java Cookie-Authenticated Downloader
    if (imgUrl && imgUrl.startsWith('http') && bridge && typeof bridge.downloadImageUrlToOutputFolder === 'function') {
      try {
        const saved = bridge.downloadImageUrlToOutputFolder(sceneNo, imgUrl, location.href);
        if (saved && !saved.startsWith('ERROR:')) {
          return true;
        }
      } catch (e) {}
    }

    // TARIKA 4: Lightbox Click -> Download Button
    if (imgEl) {
      try {
        imgEl.click();
        await sleep(1000);
        const btns = Array.from(document.querySelectorAll('button, a, [role="button"]'));
        for (const b of btns) {
          const r = b.getBoundingClientRect();
          if (r.width === 0 || r.height === 0) continue;
          const label = (b.getAttribute('aria-label') || b.getAttribute('title') || '').toLowerCase();
          if (label.includes('download')) {
            b.click();
            await sleep(2500);
            break;
          }
        }
        document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true }));
        await sleep(400);
        if (bridge && typeof bridge.doesSceneImageExist === 'function' && bridge.doesSceneImageExist(sceneNo)) {
          return true;
        }
      } catch (e) {}
    }

    return false;
  }

  async function dismissPopupsIfAny() {
    const buttons = Array.from(document.querySelectorAll('button'));
    for (const b of buttons) {
      const txt = (b.innerText || '').trim().toLowerCase();
      if (txt === 'stay logged in' || txt === 'okay' || txt === 'dismiss' || txt === 'continue') {
        try { b.click(); await sleep(300); } catch (e) {}
      }
    }
  }

  function findChatGptPromptBox() {
    return (
      document.querySelector('div#prompt-textarea[contenteditable="true"]') ||
      document.querySelector('#prompt-textarea') ||
      document.querySelector('div.ProseMirror[contenteditable="true"]') ||
      document.querySelector('textarea[placeholder]') ||
      document.querySelector('[contenteditable="true"]')
    );
  }

  function isLoginWallVisible() {
    const loginBtn = document.querySelector(
      'button[data-testid="login-button"], button[data-testid="welcome-login-button"], a[href*="/auth/login"]'
    );
    return Boolean(loginBtn);
  }

  async function waitForPromptBoxWithoutDroppingScene(sPad) {
    let notifiedWait = false;
    while (botRuntime.running) {
      await dismissPopupsIfAny();
      const box = findChatGptPromptBox();
      if (box && !isLoginWallVisible()) {
        if (notifiedWait) {
          sendHomeLog('✅ ChatGPT prompt box mil gya! Scene ' + sPad + ' ab bheja jaa rha h...', 'ok');
          syncActiveSessionIfLoggedIn();
        }
        return box;
      }

      if (!notifiedWait) {
        notifiedWait = true;
        sendHomeLog(
          '⏳ Scene ' + sPad + ': ChatGPT load ya login ka wait ho rha h (Koi bhi scene drop nahi hoga — agar login mang rha h toh upar Chatgpt tab me login karein)...',
          'warn'
        );
      }
      await sleep(1500);
    }
    return null;
  }

  async function typeAndSendPromptInSameChat(sPad, promptText, charRefName) {
    const box = await waitForPromptBoxWithoutDroppingScene(sPad);
    if (!box || !botRuntime.running) {
      return null;
    }

    if (charRefName) {
      await attachReferenceImageToChatGpt(charRefName);
    }

    const activeBox = findChatGptPromptBox() || box;
    activeBox.focus();

    if (activeBox.tagName === 'TEXTAREA') {
      activeBox.value = promptText;
      activeBox.dispatchEvent(new Event('input', { bubbles: true }));
    } else {
      activeBox.innerHTML = '<p>' + promptText.replace(/</g, '&lt;').replace(/>/g, '&gt;') + '</p>';
      activeBox.dispatchEvent(new InputEvent('input', { bubbles: true, data: promptText }));
    }
    await sleep(300);

    const beforeImgs = getLargeAssistantImages();
    const prevImgCount = beforeImgs.length;
    const prevSrcSet = new Set(beforeImgs.map((i) => i.src));

    const sendSelectors = [
      'button[data-testid="send-button"]',
      'button[aria-label*="Send prompt" i]',
      'button[aria-label*="Send" i]',
      'form button[type="submit"]'
    ];

    let sent = false;
    for (let attempt = 0; attempt < 12; attempt++) {
      for (const sel of sendSelectors) {
        const sBtn = document.querySelector(sel);
        if (sBtn && !sBtn.disabled) {
          sBtn.click();
          sent = true;
          break;
        }
      }
      if (sent) break;
      await sleep(250);
    }

    if (!sent) {
      activeBox.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true }));
    }

    return { prevImgCount, prevSrcSet };
  }

  async function runSingleChatGptScene(scene) {
    const sNo = Number(scene.scene_no);
    const sPad = String(sNo).padStart(2, '0');

    if (bridge && typeof bridge.doesSceneImageExist === 'function' && bridge.doesSceneImageExist(sNo)) {
      sendHomeLog('scene' + sPad + ' ki image pehle se output_images folder me hai (Scene_' + sPad + '.png) — skip kar rhe h.', 'ok');
      return 'done';
    }

    const readyBox = await waitForPromptBoxWithoutDroppingScene(sPad);
    if (!readyBox || !botRuntime.running) return 'stopped';

    const charRefName = detectReferenceCharName(scene.image_prompt);

    sendHomeLog('Chatgpt me scene' + sPad + ' ka prompt likha jaa rha h ....', 'LIVE');

    const fullPrompt = 'Create an image: ' + scene.image_prompt;
    const snap = await typeAndSendPromptInSameChat(sPad, fullPrompt, charRefName);
    if (!snap) return 'stopped';

    sendHomeLog(
      'Chatgpt me scene' + sPad + ' ka prompt ko send kar diya gya h ab wait kar rhe h image generate karne ka aur phir download kare ....',
      'LIVE'
    );

    await sleep(2500);

    let lastCandidateSrc = '';
    let stableCount = 0;

    for (let tick = 1; tick <= 160; tick++) {
      if (!botRuntime.running) return 'stopped';

      if (checkChatGptLimitReached()) {
        return 'rate_limit';
      }

      const refusal = checkChatGptRefusal();
      if (refusal) {
        sendHomeLog('⚠️ Scene ' + sPad + ' skipped (' + refusal + '). Agle scene par badh rhe h...', 'warn');
        return 'refused';
      }

      const currImgs = getLargeAssistantImages();
      const newImgs = currImgs.filter((item) => !snap.prevSrcSet.has(item.src));
      const hasNewImage = newImgs.length > 0 || currImgs.length > snap.prevImgCount;

      if (hasNewImage) {
        const candidate = newImgs.length > 0 ? newImgs[newImgs.length - 1] : currImgs[currImgs.length - 1];
        if (candidate && candidate.src) {
          if (candidate.src === lastCandidateSrc) {
            stableCount += 1;
          } else {
            lastCandidateSrc = candidate.src;
            stableCount = 1;
          }

          if (!isStillCreatingImage() || stableCount >= 2) {
            await sleep(700);
            const refreshed = getLargeAssistantImages();
            const refreshedNew = refreshed.filter((item) => !snap.prevSrcSet.has(item.src));
            const finalImgObj = refreshedNew.length > 0
              ? refreshedNew[refreshedNew.length - 1]
              : (refreshed.length > 0 ? refreshed[refreshed.length - 1] : candidate);

            const savedOk = await downloadAndSaveCreatedImage(sNo, finalImgObj);
            if (savedOk) {
              sendHomeLog('scene' + sPad + ' ki image download ho gyi h (output_images/Scene_' + sPad + '.png)', 'ok');
              return 'done';
            }
          }
        }
      }

      await sleep(1500);
    }

    sendHomeLog('⚠️ Scene ' + sPad + ' timeout ho gya. Agle scene par badh rhe h...', 'err');
    return 'timeout';
  }

  // ============================================================================
  // PART B — BOT 2: FLOW AI VIDEO BOT ENGINE (MOBILE & TABLET EXACT UI ENGINE)
  // ============================================================================

  let cachedFlowUserEmail = '';

  async function detectFlowLoggedInEmail() {
    if (cachedFlowUserEmail && cachedFlowUserEmail.includes('@')) {
      return cachedFlowUserEmail;
    }

    // 1. Check DOM attributes (aria-label, title, data-email) on profile avatar / header buttons
    try {
      const allEls = Array.from(document.querySelectorAll('[aria-label*="@"], [title*="@"], [data-email*="@"], a, button, span, div'));
      for (const el of allEls) {
        const raw = (
          (el.getAttribute && (el.getAttribute('aria-label') || el.getAttribute('title') || el.getAttribute('data-email'))) ||
          ''
        );
        const m = raw.match(/([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/);
        if (m && m[1]) {
          cachedFlowUserEmail = m[1].toLowerCase();
          return cachedFlowUserEmail;
        }
      }
    } catch (e) {}

    // 2. Check page scripts / __NEXT_DATA__ for logged-in email
    try {
      const scripts = Array.from(document.querySelectorAll('script'));
      for (const s of scripts) {
        const txt = s.textContent || '';
        if (txt.includes('@gmail.com') || txt.includes('"email"')) {
          const m = txt.match(/([a-zA-Z0-9._%+-]+@gmail\.com)/i) || txt.match(/"email"\s*:\s*"([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})"/i);
          if (m && m[1]) {
            cachedFlowUserEmail = m[1].toLowerCase();
            return cachedFlowUserEmail;
          }
        }
      }
    } catch (e) {}

    // 3. Try fetching /fx/api/auth/session
    try {
      const resp = await fetch('/fx/api/auth/session', { credentials: 'include' });
      if (resp.ok) {
        const data = await resp.json();
        if (data && data.user && data.user.email) {
          cachedFlowUserEmail = String(data.user.email).toLowerCase();
          return cachedFlowUserEmail;
        }
      }
    } catch (e) {}

    return cachedFlowUserEmail || '';
  }

  function setupFlowPageEnvironmentAndLoginHelper() {
    const isFlowHost = location.hostname.includes('labs.google') || location.hostname.includes('flow.google');
    if (!isFlowHost) return;

    try {
      window.open = function (u) {
        if (u && typeof u === 'string' && u !== 'about:blank') {
          window.location.href = u;
          return window;
        }
        return {
          closed: false,
          focus: function () {},
          close: function () {},
          location: {
            set href(v) { if (v && v !== 'about:blank') window.location.href = v; },
            get href() { return window.location.href; },
            assign: function (v) { if (v) window.location.href = v; },
            replace: function (v) { if (v) window.location.replace(v); }
          }
        };
      };
    } catch (e) {}

    document.addEventListener('click', function (ev) {
      const el = ev.target && ev.target.closest ? ev.target.closest('button, a, [role="button"]') : null;
      if (!el) return;
      if (el.tagName === 'A' && el.hasAttribute('target')) {
        el.removeAttribute('target');
      }
      const txt = (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim().toLowerCase();
      if (txt.includes('create with google flow') || txt === 'create with flow' || txt === 'sign in') {
        try {
          sessionStorage.setItem('itk_flow_create_clicked_ts', String(Date.now()));
        } catch (e) {}
      }
    }, true);

    setTimeout(() => {
      if (location.href.includes('/project/')) return;
      const allBtns = Array.from(document.querySelectorAll('button, a, [role="button"]'));
      const createBtn = allBtns.find((b) => {
        const t = (b.innerText || b.textContent || '').replace(/\s+/g, ' ').trim().toLowerCase();
        return t.includes('create with google flow');
      });
      if (!createBtn) return;

      let clickedTs = 0;
      try {
        clickedTs = Number(sessionStorage.getItem('itk_flow_create_clicked_ts') || 0);
      } catch (e) {}

      if (clickedTs > 0 && (Date.now() - clickedTs) < 5500) {
        try {
          sessionStorage.removeItem('itk_flow_create_clicked_ts');
        } catch (e) {}
        sendHomeLog('Opening Google Account Sign-In...', 'LIVE');
        location.href = 'https://accounts.google.com/';
      }
    }, 900);
  }

  setupFlowPageEnvironmentAndLoginHelper();

  function dispatchRealClick(el, customX, customY) {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    const cx = customX !== undefined ? customX : (r.left + r.width / 2);
    const cy = customY !== undefined ? customY : (r.top + r.height / 2);
    if (bridge && typeof bridge.nativeTapAtCssPoint === 'function') {
      try {
        bridge.nativeTapAtCssPoint(2, cx, cy, window.innerWidth || 800, window.innerHeight || 1200);
      } catch (e) {}
    }
    const opts = { bubbles: true, cancelable: true, view: window, clientX: cx, clientY: cy, button: 0, buttons: 1 };
    try {
      el.dispatchEvent(new PointerEvent('pointerdown', opts));
      el.dispatchEvent(new MouseEvent('mousedown', opts));
      el.dispatchEvent(new PointerEvent('pointerup', opts));
      el.dispatchEvent(new MouseEvent('mouseup', opts));
      el.dispatchEvent(new MouseEvent('click', opts));
    } catch (e) {}
    try {
      el.click();
    } catch (e) {}
    return true;
  }

  // Sends a pure OS-level Android MotionEvent (ACTION_DOWN + ACTION_UP) without a duplicate JS .click()
  // so toggle menus (like '+' dropdown and Settings Pill) don't open and immediately close!
  async function nativeHardwareTap(el, customX, customY) {
    if (!el && customX === undefined) return false;
    let cx = customX;
    let cy = customY;
    if (el) {
      const r = el.getBoundingClientRect();
      cx = customX !== undefined ? customX : (r.left + r.width / 2);
      cy = customY !== undefined ? customY : (r.top + r.height / 2);
    }
    if (bridge && typeof bridge.nativeTapAtCssPoint === 'function') {
      bridge.nativeTapAtCssPoint(2, cx, cy, window.innerWidth || 800, window.innerHeight || 1200);
      await sleep(160);
      return true;
    }
    return dispatchRealClick(el, cx, cy);
  }

  function dismissAllFlowPopupsOnce() {
    // 1. Red Google Security Alert: "Did you request help signing in?" -> click X, NEVER Review
    const allContainers = Array.from(document.querySelectorAll('div, section, aside, [role="dialog"], [role="alert"], [role="region"], dialog'));
    for (const box of allContainers) {
      const r = box.getBoundingClientRect();
      if (r.width < 140 || r.height < 55 || r.width > 750 || r.height > 520) continue;
      const boxTxt = (box.innerText || '').toLowerCase();
      if (
        boxTxt.includes('did you request help signing in') ||
        boxTxt.includes('request to help you sign in') ||
        boxTxt.includes('review the request')
      ) {
        const candidates = Array.from(box.querySelectorAll('button, [role="button"], a, span, div'));
        for (const c of candidates) {
          const cr = c.getBoundingClientRect();
          if (cr.width === 0 || cr.height === 0 || cr.width > 55 || cr.height > 55) continue;
          const cTxt = (c.innerText || c.textContent || '').trim().toLowerCase();
          const cAria = (c.getAttribute('aria-label') || c.getAttribute('title') || '').trim().toLowerCase();
          if (cTxt.includes('review') || cAria.includes('review')) continue;
          if (['x', '✕', '✖', '×', '⨯', 'close'].includes(cTxt) || cAria.includes('close') || cAria.includes('dismiss')) {
            dispatchRealClick(c);
            return 'security-alert-close';
          }
        }
      }
    }

    // 2. Standard consent / welcome dialogs
    const allClickable = Array.from(document.querySelectorAll('button, [role="button"], a'));
    const dismissWords = ['okay', 'ok', 'got it', 'i understand', 'agree', 'i agree', 'accept', 'continue', 'skip', 'dismiss', 'no thanks'];
    for (const el of allClickable) {
      const rect = el.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) continue;
      const txt = (el.innerText || el.textContent || '').trim().toLowerCase();
      const aria = (el.getAttribute('aria-label') || el.getAttribute('title') || '').trim().toLowerCase();
      if (txt === 'review' || aria.includes('review')) continue;
      if (dismissWords.includes(txt) || dismissWords.includes(aria)) {
        dispatchRealClick(el);
        return 'popup:' + (txt || aria);
      }
    }
    return null;
  }

  async function dismissAllFlowPopups() {
    for (let i = 0; i < 3; i++) {
      if (dismissAllFlowPopupsOnce()) {
        await sleep(500);
      } else {
        break;
      }
    }
  }

  async function enterFlowProject() {
    await dismissAllFlowPopups();
    if (location.href.includes('/project/')) return true;

    sendHomeLog('Flow AI me "+ New project" khola jaa rha h...', 'LIVE');
    for (let attempt = 0; attempt < 5; attempt++) {
      if (location.href.includes('/project/')) return true;
      await dismissAllFlowPopups();

      const els = Array.from(document.querySelectorAll('button, a, [role="button"], div, span'));
      for (const el of els) {
        const r = el.getBoundingClientRect();
        if (r.width < 50 || r.width > 420 || r.height < 20 || r.height > 100) continue;
        if (r.top < 0 || r.top > window.innerHeight) continue;
        const txt = (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim().toLowerCase();
        if (
          txt === 'new project' ||
          txt === '+ new project' ||
          txt === 'add new project' ||
          txt.endsWith('new project') ||
          txt === 'create with flow'
        ) {
          dispatchRealClick(el);
          break;
        }
      }

      for (let w = 0; w < 12; w++) {
        if (location.href.includes('/project/')) return true;
        await sleep(500);
      }
    }
    await sleep(1500);
    await dismissAllFlowPopups();
    return location.href.includes('/project/');
  }

  // Ensures we are on the main project canvas ("What do you want to create?"),
  // NOT stuck inside a single clicked image/video preview ("What do you want to change?" at 01:29 of Video 1)
  async function ensureOnMainProjectCanvas() {
    const bodyTxt = (document.body.innerText || '').toLowerCase();
    const isSingleAssetView = bodyTxt.includes('what do you want to change') ||
      Array.from(document.querySelectorAll('textarea, [contenteditable="true"], [role="textbox"], div, span')).some((el) => {
        const ph = (el.getAttribute('placeholder') || el.getAttribute('data-placeholder') || el.innerText || '').toLowerCase();
        return ph.includes('what do you want to change');
      });

    if (isSingleAssetView) {
      // Click the top-left '←' Back arrow button (r.top < 95, r.left < 90)
      const backBtn = Array.from(document.querySelectorAll('button, [role="button"], a')).find((b) => {
        const r = b.getBoundingClientRect();
        return r.width > 16 && r.width < 75 && r.height > 16 && r.height < 75 && r.top >= 4 && r.top <= 95 && r.left >= 2 && r.left <= 95;
      });
      if (backBtn) {
        dispatchRealClick(backBtn);
        await sleep(1000);
      }
    }
  }

  // ============================================================================
  // MOBILE & DESKTOP COMPOSER LOCATORS (NO 'AGENT' BUTTON REQUIRED!)
  // ============================================================================

  // Finds the Settings Pill button in the bottom composer bar:
  // e.g. "🍌 Nano Banana 2.1 [▢] x1" or "Video · 720p · 6s · x1" or "Video · 720p · 6s · x3"
  function findFlowSettingsPillButton() {
    const btns = Array.from(document.querySelectorAll('button, [role="button"]'));
    const candidates = btns.filter((b) => {
      const r = b.getBoundingClientRect();
      if (r.width < 55 || r.width > 340 || r.height < 20 || r.height > 68) return false;
      if (r.top < window.innerHeight * 0.52) return false;
      const t = (b.innerText || b.textContent || '').replace(/\s+/g, ' ').trim().toLowerCase();
      if (t === 'video' || t === 'image' || t === 'frames' || t === 'ingredients') return false;
      return (
        t.includes('nano banana') ||
        t.includes('720p') ||
        t.includes('360p') ||
        t.includes('1080p') ||
        t.includes('omni') ||
        t.includes('veo') ||
        t.includes('imagen') ||
        (t.includes('video') && (t.includes('x1') || t.includes('x2') || t.includes('x3') || t.includes('x4') || t.includes('6s') || t.includes('4s') || t.includes('8s'))) ||
        (t.includes('image') && (t.includes('x1') || t.includes('x2') || t.includes('x3') || t.includes('x4'))) ||
        /\bx[1-4]\b/.test(t)
      );
    });

    if (candidates.length === 0) return null;
    // Pick the one lowest on screen (inside the bottom composer bar, not inside an open popover)
    candidates.sort((a, b) => b.getBoundingClientRect().top - a.getBoundingClientRect().top);
    return candidates[0];
  }

  function findFlowPromptTextbox() {
    const all = Array.from(document.querySelectorAll('textarea, [contenteditable="true"], [role="textbox"]'));
    const matches = all.filter((el) => {
      const r = el.getBoundingClientRect();
      if (r.width < 80 || r.height < 16 || r.top < window.innerHeight * 0.45) return false;
      return true;
    });
    if (matches.length > 0) {
      matches.sort((a, b) => b.getBoundingClientRect().top - a.getBoundingClientRect().top);
      return matches[0];
    }

    // Fallback: look for placeholder text "What do you want to create?"
    const phEl = Array.from(document.querySelectorAll('div, span, p')).find((el) => {
      const r = el.getBoundingClientRect();
      if (r.width < 80 || r.height < 14 || r.top < window.innerHeight * 0.48) return false;
      const t = (el.getAttribute('placeholder') || el.getAttribute('data-placeholder') || el.innerText || '').trim().toLowerCase();
      return t === 'what do you want to create?' || t === 'what do you want to create';
    });
    return phEl || null;
  }

  function findFlowComposerContainer() {
    const anchor = findFlowSettingsPillButton() || findFlowPromptTextbox();
    if (!anchor) return null;
    let cur = anchor.parentElement;
    while (cur && cur !== document.body) {
      const r = cur.getBoundingClientRect();
      if (r.width >= window.innerWidth * 0.45 && r.height >= 65 && r.height <= 340 && r.top > window.innerHeight * 0.42) {
        return cur;
      }
      cur = cur.parentElement;
    }
    return anchor.parentElement;
  }

  // Finds the Bottom-Left '+' button inside the prompt composer box (shown at 00:54 & 01:05 of Video 2)
  async function clickComposerBottomLeftPlusButton() {
    const pill = findFlowSettingsPillButton();
    const composer = findFlowComposerContainer();
    const btns = Array.from(document.querySelectorAll('button, [role="button"]'));

    if (pill) {
      const pRect = pill.getBoundingClientRect();
      const rowLeftBtns = btns.filter((b) => {
        if (b === pill) return false;
        const r = b.getBoundingClientRect();
        if (r.width < 18 || r.width > 72 || r.height < 18 || r.height > 72) return false;
        if (Math.abs((r.top + r.height / 2) - (pRect.top + pRect.height / 2)) > 42) return false;
        if (r.left >= pRect.left - 16) return false;
        return true;
      }).sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left);

      if (rowLeftBtns.length > 0) {
        await nativeHardwareTap(rowLeftBtns[0]);
        return true;
      }
    }

    if (composer) {
      const cRect = composer.getBoundingClientRect();
      const insideLeft = Array.from(composer.querySelectorAll('button, [role="button"]')).filter((b) => {
        const r = b.getBoundingClientRect();
        return r.width >= 18 && r.width <= 72 && r.height >= 18 && r.height <= 72 &&
          r.left < cRect.left + 125 && r.top > cRect.top + cRect.height * 0.30;
      }).sort((a, b) => b.getBoundingClientRect().top - a.getBoundingClientRect().top);

      if (insideLeft.length > 0) {
        await nativeHardwareTap(insideLeft[0]);
        return true;
      }
    }
    return false;
  }

  // Finds the exact Top-Right '+' button in Row 1 of the header bar ([+] [?] [⋮] [PRO] [S])
  function getHeaderTopRightPlusCandidates() {
    const allEls = Array.from(document.querySelectorAll('button, [role="button"], span, div'));
    const proBadge = allEls.find((el) => {
      const r = el.getBoundingClientRect();
      return r.top >= 0 && r.top <= 75 && r.left > window.innerWidth * 0.50 &&
        (el.innerText || el.textContent || '').trim().toUpperCase() === 'PRO';
    });

    const allBtns = Array.from(document.querySelectorAll('button, [role="button"]'));
    let headerRightBtns = [];

    if (proBadge) {
      const pRect = proBadge.getBoundingClientRect();
      const proCy = pRect.top + pRect.height / 2;
      headerRightBtns = allBtns.filter((b) => {
        const r = b.getBoundingClientRect();
        if (r.width < 16 || r.width > 75 || r.height < 16 || r.height > 75) return false;
        const cy = r.top + r.height / 2;
        if (Math.abs(cy - proCy) > 22) return false;
        if (r.left < window.innerWidth * 0.40 || r.right > pRect.left + 6) return false;
        return true;
      }).sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left);
    }

    if (headerRightBtns.length === 0) {
      headerRightBtns = allBtns.filter((b) => {
        const r = b.getBoundingClientRect();
        if (r.width < 16 || r.width > 75 || r.height < 16 || r.height > 75) return false;
        if (r.top < 2 || r.top > 56) return false;
        if (r.left < window.innerWidth * 0.45 || r.left > window.innerWidth * 0.88) return false;
        const t = (b.innerText || b.textContent || '').trim().toLowerCase();
        if (t === 'pro') return false;
        return true;
      }).sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left);
    }

    const explicitPlus = headerRightBtns.filter((b) => {
      const t = (b.innerText || b.textContent || '').trim().toLowerCase();
      const aria = (b.getAttribute('aria-label') || b.getAttribute('title') || '').trim().toLowerCase();
      return t === '+' || t === 'add' || aria.includes('add') || aria.includes('upload') || aria.includes('create');
    });

    const combined = [...explicitPlus];
    for (const b of headerRightBtns) {
      if (!combined.includes(b)) combined.push(b);
    }
    return combined;
  }

  function isSettingsPillAlreadyConfigured() {
    const pill = findFlowSettingsPillButton();
    if (!pill) return false;
    const t = (pill.innerText || pill.textContent || '').replace(/\s+/g, ' ').trim().toLowerCase();
    return t.includes('video') && t.includes('720p') && t.includes('6s') && t.includes('x1');
  }

  async function tapOptionInsideSettingsPopover(targetWords, pillTopY) {
    const lowerTargets = targetWords.map((w) => w.toLowerCase());
    const maxBottom = (pillTopY || window.innerHeight * 0.85) - 4;
    const els = Array.from(document.querySelectorAll('button, [role="button"], [role="tab"], [role="option"], [role="radio"], [role="menuitem"], div, span'));

    for (const target of lowerTargets) {
      const matches = els.filter((el) => {
        const r = el.getBoundingClientRect();
        if (r.width < 22 || r.width > 320 || r.height < 16 || r.height > 75) return false;
        if (r.top < 50 || r.bottom > maxBottom) return false;
        const txt = (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim().toLowerCase();
        return txt === target;
      });

      if (matches.length > 0) {
        matches.sort((a, b) => (a.children.length - b.children.length));
        const best = matches[0].closest('button, [role="button"], [role="tab"], [role="option"], [role="radio"]') || matches[0];
        await nativeHardwareTap(best);
        return target;
      }
    }
    return null;
  }

  async function ensureFlowVideoSettingsConfigured() {
    if (isSettingsPillAlreadyConfigured()) {
      botRuntime.flowSettingsConfigured = true;
      return true;
    }

    const pill = findFlowSettingsPillButton();
    if (!pill) return false;

    const pillRect = pill.getBoundingClientRect();
    sendHomeLog('Flow AI Settings set kiye jaa rhe h (Video | 16:9 | Omni 3.1 Flash | 720p | 6s | x1)...', 'LIVE');
    await nativeHardwareTap(pill);
    await sleep(1100);

    // 1. Tap "Video"
    await tapOptionInsideSettingsPopover(['video'], pillRect.top);
    await sleep(850);

    // 2. Tap "16:9"
    await tapOptionInsideSettingsPopover(['16:9'], pillRect.top);
    await sleep(450);

    // 3. Ensure Model is "Omni 3.1 Flash"
    const popTxt = (document.body.innerText || '').toLowerCase();
    if (!popTxt.includes('omni 3.1 flash') && !popTxt.includes('omni flash')) {
      await tapOptionInsideSettingsPopover(['veo 3.1', 'veo 3', 'veo 2', 'veo', 'nano banana 2.1', 'imagen'], pillRect.top);
      await sleep(700);
      await tapOptionInsideSettingsPopover(['omni 3.1 flash', 'omni flash'], pillRect.top);
      await sleep(500);
    }

    // 4. Tap "720p"
    await tapOptionInsideSettingsPopover(['720p'], pillRect.top);
    await sleep(450);

    // 5. Tap "6s"
    await tapOptionInsideSettingsPopover(['6s', '6 sec', '6 seconds'], pillRect.top);
    await sleep(450);

    // 6. Tap "x1"
    await tapOptionInsideSettingsPopover(['x1', '×1'], pillRect.top);
    await sleep(550);

    // 7. Close popover by tapping the '✕' inside the popover or tapping the Settings Pill again
    if ((document.body.innerText || '').toLowerCase().includes('generating will use')) {
      const pillAfter = findFlowSettingsPillButton();
      if (pillAfter) await nativeHardwareTap(pillAfter);
      await sleep(500);
    }

    botRuntime.flowSettingsConfigured = isSettingsPillAlreadyConfigured();
    return true;
  }

  function isSceneImageAlreadyOnCanvas(imgFilename, imgStem) {
    const fLower = imgFilename.toLowerCase();
    const sLower = imgStem.toLowerCase();
    const els = Array.from(document.querySelectorAll('div, span, p'));
    return els.some((el) => {
      if (el.children.length > 2) return false;
      const r = el.getBoundingClientRect();
      if (r.width === 0 || r.height === 0 || r.top > window.innerHeight * 0.78) return false;
      const t = (el.innerText || el.textContent || '').trim().toLowerCase();
      return t === fLower || t === sLower;
    });
  }

  function isAnyUploadOrRenderPercentageVisible() {
    const els = Array.from(document.querySelectorAll('div, span, p'));
    return els.some((el) => {
      if (el.children.length > 0) return false;
      const r = el.getBoundingClientRect();
      if (r.width === 0 || r.height === 0) return false;
      const txt = (el.innerText || el.textContent || '').trim();
      return /^\d{1,3}%$/.test(txt);
    });
  }

  function isImageAttachedInComposer() {
    const composer = findFlowComposerContainer();
    if (!composer) return false;
    const cRect = composer.getBoundingClientRect();
    const imgs = Array.from(composer.querySelectorAll('img'));
    for (const im of imgs) {
      const r = im.getBoundingClientRect();
      if (r.width >= 22 && r.width <= 150 && r.height >= 22 && r.height <= 150) {
        return true;
      }
    }
    const removeBtns = Array.from(composer.querySelectorAll('button, [role="button"]')).filter((b) => {
      const r = b.getBoundingClientRect();
      return r.width >= 12 && r.width <= 36 && r.height >= 12 && r.height <= 36 &&
        r.left < cRect.left + 150 && r.top < cRect.top + cRect.height * 0.58;
    });
    return removeBtns.length > 0;
  }

  function findVisibleUploadMenuItem() {
    const menuEls = Array.from(document.querySelectorAll('[role="menuitem"], button, li, div[role="button"], span, div'));
    const matches = menuEls.filter((el) => {
      const r = el.getBoundingClientRect();
      if (r.width < 35 || r.width > 280 || r.height < 16 || r.height > 70 || r.top < 25 || r.top > 300) return false;
      const t = (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim().toLowerCase();
      return t === 'upload' || t === 'upload media';
    });
    if (matches.length === 0) return null;
    matches.sort((a, b) => a.children.length - b.children.length);
    return matches[0].closest('[role="menuitem"], button, [role="button"], li') || matches[0];
  }

  // Uses real Android hardware touch (nativeHardwareTap) so Chromium grants User Activation
  // and immediately fires WebChromeClient.onShowFileChooser when 'Upload' is tapped!
  async function uploadAndAttachFlowSceneImage(sceneNo) {
    const sPad = String(sceneNo).padStart(2, '0');
    const imgFilename = 'Scene_' + sPad + '.png';
    const imgStem = 'Scene_' + sPad;

    let b64Data = '';
    if (bridge && typeof bridge.getSceneImageBase64 === 'function') {
      b64Data = bridge.getSceneImageBase64(sceneNo);
    }
    if (!b64Data || !b64Data.startsWith('data:image')) {
      sendHomeLog('⚠️ ' + imgFilename + ' output_images folder me nahi mili!', 'warn');
      return false;
    }

    if (bridge && typeof bridge.setPendingAutoUploadSceneImage === 'function') {
      bridge.setPendingAutoUploadSceneImage(sceneNo);
    }

    let alreadyUploaded = isSceneImageAlreadyOnCanvas(imgFilename, imgStem);
    if (!alreadyUploaded) {
      let uploadStarted = false;

      // Method 1: Tap Top-Right '+' in header -> tap 'Upload' using real Android hardware touch!
      const headerCandidates = getHeaderTopRightPlusCandidates();
      for (let i = 0; i < Math.min(3, headerCandidates.length) && !uploadStarted; i++) {
        await nativeHardwareTap(headerCandidates[i]);
        await sleep(950);

        const uploadItem = findVisibleUploadMenuItem();
        if (uploadItem) {
          if (bridge && typeof bridge.setPendingAutoUploadSceneImage === 'function') {
            bridge.setPendingAutoUploadSceneImage(sceneNo);
          }
          await nativeHardwareTap(uploadItem);
          await sleep(1600);

          const consumed = (bridge && typeof bridge.isPendingAutoUploadConsumed === 'function')
            ? bridge.isPendingAutoUploadConsumed()
            : false;
          if (consumed || isAnyUploadOrRenderPercentageVisible() || isSceneImageAlreadyOnCanvas(imgFilename, imgStem)) {
            uploadStarted = true;
            break;
          }
        }
      }

      // Method 2: Open Bottom-Left '+' Asset Drawer -> tap the '↑' Upload button at the top-right of the Search bar!
      if (!uploadStarted) {
        if (await clickComposerBottomLeftPlusButton()) {
          await sleep(1200);
          const searchInput = document.querySelector('input[placeholder*="Search" i]');
          if (searchInput) {
            const sRect = searchInput.getBoundingClientRect();
            const upIconBtn = Array.from(document.querySelectorAll('button, [role="button"]')).find((b) => {
              const r = b.getBoundingClientRect();
              return r.width >= 18 && r.width <= 72 && r.height >= 18 && r.height <= 72 &&
                Math.abs((r.top + r.height / 2) - (sRect.top + sRect.height / 2)) < 38 &&
                r.left >= sRect.right - 12;
            });
            if (upIconBtn) {
              if (bridge && typeof bridge.setPendingAutoUploadSceneImage === 'function') {
                bridge.setPendingAutoUploadSceneImage(sceneNo);
              }
              await nativeHardwareTap(upIconBtn);
              await sleep(1600);
              const consumed = (bridge && typeof bridge.isPendingAutoUploadConsumed === 'function')
                ? bridge.isPendingAutoUploadConsumed()
                : false;
              if (consumed || isAnyUploadOrRenderPercentageVisible()) {
                uploadStarted = true;
              }
            }
          }
          // Close asset drawer while upload progresses on canvas
          const closeDrawerX = Array.from(document.querySelectorAll('button, [role="button"]')).find((b) => {
            const r = b.getBoundingClientRect();
            return r.top > 40 && r.top < 140 && r.left > window.innerWidth * 0.84 && r.width <= 65;
          });
          if (closeDrawerX) await nativeHardwareTap(closeDrawerX);
          await sleep(500);
        }
      }

      // Wait for upload percentage (0% -> 99% -> 100%) to complete on canvas!
      sendHomeLog('Flow AI me ' + imgFilename + ' 100% upload hone ka wait ho rha h...', 'LIVE');
      await sleep(2500);
      let sawPercent = false;
      for (let w = 0; w < 45; w++) {
        if (isAnyUploadOrRenderPercentageVisible()) {
          sawPercent = true;
        } else if (sawPercent || isSceneImageAlreadyOnCanvas(imgFilename, imgStem) || w >= 5) {
          break;
        }
        await sleep(1500);
      }
      await sleep(1500);
    }

    // STEP C: Open Bottom-Left '+' in Composer -> Search 'Scene_XX' -> Tap 'Scene_XX.png' row to attach!
    sendHomeLog('Flow AI me + menu se ' + imgFilename + ' search karke prompt me attach kiya jaa rha h...', 'LIVE');
    for (let attempt = 0; attempt < 3; attempt++) {
      if (isImageAttachedInComposer()) {
        return true;
      }

      let searchBox = document.querySelector('input[placeholder*="Search" i]');
      if (!searchBox || searchBox.getBoundingClientRect().width === 0) {
        await clickComposerBottomLeftPlusButton();
        await sleep(1400);
        searchBox = document.querySelector('input[placeholder*="Search" i]');
      }

      if (searchBox && searchBox.getBoundingClientRect().width > 0) {
        await nativeHardwareTap(searchBox);
        searchBox.focus();
        await sleep(300);

        try {
          document.execCommand('selectAll', false, null);
          document.execCommand('delete', false, null);
          document.execCommand('insertText', false, imgStem);
        } catch (e) {}

        if ((searchBox.value || '').toLowerCase() !== imgStem.toLowerCase()) {
          try {
            const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
            setter.call(searchBox, imgStem);
          } catch (e) {
            searchBox.value = imgStem;
          }
        }
        searchBox.dispatchEvent(new InputEvent('input', { bubbles: true, cancelable: true, data: imgStem }));
        searchBox.dispatchEvent(new Event('change', { bubbles: true }));
        await sleep(1400);
      }

      // Find the matching 'Scene_XX.png' row below the Search bar (Video 2 at 01:15 - 01:18)
      const sBoxRect = searchBox ? searchBox.getBoundingClientRect() : { bottom: 90 };
      const allRows = Array.from(document.querySelectorAll('div, button, li, [role="option"], [role="menuitem"], [role="button"], span'));
      const matchingRow = allRows.find((el) => {
        const r = el.getBoundingClientRect();
        if (r.width < 45 || r.height < 16 || r.height > 110) return false;
        if (r.top < sBoxRect.bottom - 5 || r.top > window.innerHeight * 0.85) return false;
        const txt = (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim().toLowerCase();
        return txt.includes(imgFilename.toLowerCase()) || txt === imgStem.toLowerCase() || txt.startsWith(imgStem.toLowerCase() + '.png');
      });

      if (matchingRow) {
        const clickableRow = matchingRow.closest('button, [role="button"], [role="option"], [role="menuitem"], li, div') || matchingRow;
        await nativeHardwareTap(clickableRow);
        await sleep(1200);

        // If on desktop view where "Add to prompt" button appears, tap it too
        const addBtn = Array.from(document.querySelectorAll('button, [role="button"], div, span')).find((b) => {
          const r = b.getBoundingClientRect();
          return r.width > 0 && r.height > 0 && r.height <= 80 && (b.innerText || b.textContent || '').trim().toLowerCase() === 'add to prompt';
        });
        if (addBtn) {
          await nativeHardwareTap(addBtn);
          await sleep(1000);
        }

        if (isImageAttachedInComposer() || !document.querySelector('input[placeholder*="Search" i]')) {
          return true;
        }
      }

      await sleep(1000);
    }

    return isImageAttachedInComposer();
  }

  // Finds and clicks the round '→' Send button strictly inside the bottom-right of the composer box,
  // immediately to the right of the 'Video · 720p · 6s · x1' Settings Pill (Video 2 at 01:53)!
  async function findAndClickFlowComposerSendButton() {
    const pill = findFlowSettingsPillButton();
    const btns = Array.from(document.querySelectorAll('button, [role="button"]'));

    if (pill) {
      const pRect = pill.getBoundingClientRect();
      const rightOfPill = btns.filter((b) => {
        if (b === pill) return false;
        const r = b.getBoundingClientRect();
        if (r.width < 18 || r.width > 72 || r.height < 18 || r.height > 72) return false;
        if (Math.abs((r.top + r.height / 2) - (pRect.top + pRect.height / 2)) > 36) return false;
        if (r.left < pRect.right - 8 || r.left > pRect.right + 95) return false;
        return true;
      }).sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left);

      if (rightOfPill.length > 0) {
        await nativeHardwareTap(rightOfPill[0]);
        return true;
      }

      const tx = pRect.right + 28;
      const ty = pRect.top + pRect.height / 2;
      await nativeHardwareTap(null, tx, ty);
      return true;
    }

    const composer = findFlowComposerContainer();
    if (composer) {
      const cRect = composer.getBoundingClientRect();
      const cBtns = Array.from(composer.querySelectorAll('button, [role="button"]')).filter((b) => {
        const r = b.getBoundingClientRect();
        return r.width >= 20 && r.width <= 68 && r.height >= 20 && r.height <= 68 &&
          r.left > cRect.right - 90 && r.top > cRect.top + cRect.height * 0.35;
      }).sort((a, b) => b.getBoundingClientRect().left - a.getBoundingClientRect().left);

      if (cBtns.length > 0) {
        await nativeHardwareTap(cBtns[0]);
        return true;
      }
    }
    return false;
  }

  function isFlowPromptStillInComposer(videoPrompt) {
    const snippet = String(videoPrompt || '').trim().slice(0, 24).toLowerCase();
    if (!snippet) return false;
    const els = Array.from(document.querySelectorAll('textarea, [contenteditable="true"], [role="textbox"], div, p, span'));
    for (const el of els) {
      const r = el.getBoundingClientRect();
      if (r.top < window.innerHeight * 0.45 || r.width === 0 || r.height === 0) continue;
      const txt = (el.innerText || el.value || el.textContent || '').trim().toLowerCase();
      if (txt.includes(snippet)) return true;
    }
    return false;
  }

  async function typeFlowPromptAndClickSend(videoPrompt) {
    // 1. Ensure asset search drawer or settings popover is closed first
    if (document.querySelector('input[placeholder*="Search" i]')) {
      const closeX = Array.from(document.querySelectorAll('button, [role="button"]')).find((b) => {
        const r = b.getBoundingClientRect();
        return r.top > 40 && r.top < 140 && r.left > window.innerWidth * 0.85 && r.width <= 60;
      });
      if (closeX) dispatchRealClick(closeX);
      else document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true }));
      await sleep(600);
    }

    // 2. Focus 'What do you want to create?' prompt box
    let box = findFlowPromptTextbox();
    if (!box) throw new Error('Flow AI prompt box ("What do you want to create?") nahi mila');

    await nativeHardwareTap(box);
    if (box.focus) box.focus();
    await sleep(350);

    // If clicking the placeholder div focused an inner contenteditable/textarea, use document.activeElement
    if (document.activeElement && document.activeElement !== document.body &&
        (document.activeElement.tagName === 'TEXTAREA' || document.activeElement.tagName === 'INPUT' || document.activeElement.isContentEditable)) {
      box = document.activeElement;
    }

    // 3. Insert prompt text cleanly
    let inserted = false;
    try {
      document.execCommand('selectAll', false, null);
      document.execCommand('delete', false, null);
      inserted = document.execCommand('insertText', false, videoPrompt);
    } catch (e) {}

    if (!inserted || !isFlowPromptStillInComposer(videoPrompt)) {
      if (box.tagName === 'TEXTAREA' || box.tagName === 'INPUT') {
        try {
          const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
          setter.call(box, videoPrompt);
        } catch (e) {
          box.value = videoPrompt;
        }
      } else {
        box.textContent = videoPrompt;
      }
    }

    box.dispatchEvent(new InputEvent('input', { bubbles: true, cancelable: true, data: videoPrompt }));
    box.dispatchEvent(new Event('change', { bubbles: true }));
    await sleep(900);

    // 4. Make sure Settings Pill is set to Video · 720p · 6s · x1 right before clicking Send (just like Video 2 at 01:21 - 01:53!)
    await ensureFlowVideoSettingsConfigured();
    await sleep(500);

    // 5. Click the round '→' Send button strictly inside the composer bar
    await findAndClickFlowComposerSendButton();
    await sleep(2200);

    // 6. Verify that the prompt actually left the composer box; if still in box, retry clicking '→' Send!
    for (let retry = 0; retry < 3; retry++) {
      if (!isFlowPromptStillInComposer(videoPrompt)) {
        return true;
      }
      await findAndClickFlowComposerSendButton();
      await sleep(1500);
    }

    return !isFlowPromptStillInComposer(videoPrompt);
  }

  // ============================================================================
  // VIDEO COMPLETION, INLINE 'FAILED' CARD DETECTION (VIDEO 2 @ 04:07) & CREDITS
  // ============================================================================

  function getFlowRemainingCredits() {
    const els = Array.from(document.querySelectorAll('button, span, div, a, p'));
    for (const el of els) {
      if (el.children.length > 2) continue;
      const r = el.getBoundingClientRect();
      if (r.width === 0 || r.height === 0) continue;
      const txt = (el.innerText || el.textContent || '').trim();
      if (!txt || txt.length > 45) continue;
      const aria = (el.getAttribute('aria-label') || el.getAttribute('title') || '').trim();
      const combined = (txt + ' ' + aria).toLowerCase();
      let m = combined.match(/(\d[\d,]*)\s*credits?(?:\s+left|\s+remaining)?/i);
      if (!m) m = combined.match(/credits?\s*[:\-]?\s*(\d[\d,]*)/i);
      if (m) {
        const num = parseInt(m[1].replace(/,/g, ''), 10);
        if (!isNaN(num) && num >= 0 && num <= 500000) return num;
      }
    }
    return null;
  }

  // Counts ONLY completed Video cards on the project canvas (ignoring uploaded static PNG image cards!)
  function countCompletedFlowVideoCards() {
    const maxTop = window.innerHeight * 0.78;
    const seenRects = [];

    // 1. Check <video> elements on canvas
    const vids = Array.from(document.querySelectorAll('video'));
    for (const v of vids) {
      const r = v.getBoundingClientRect();
      if (r.width < 120 || r.height < 65 || r.top < 35 || r.top > maxTop) continue;
      const isDup = seenRects.some((sr) => Math.abs(sr.left - r.left) < 30 && Math.abs(sr.top - r.top) < 30);
      if (!isDup) seenRects.push(r);
    }

    // 2. Also check cards that are NOT static '.png'/'.jpg' image cards and have a video play badge or prompt label
    const allCards = Array.from(document.querySelectorAll('[data-testid*="card"], [class*="card"], div'));
    for (const c of allCards) {
      const r = c.getBoundingClientRect();
      if (r.width < 220 || r.height < 110 || r.height > 480 || r.top < 40 || r.top > maxTop) continue;
      const txt = (c.innerText || '').trim();
      if (!txt || txt.length > 180) continue;
      const lower = txt.toLowerCase();
      if (lower.endsWith('.png') || lower.endsWith('.jpg') || lower.startsWith('failed') || /^\d{1,3}%$/.test(lower)) continue;
      const hasVideoTag = Boolean(c.querySelector('video'));
      if (hasVideoTag) {
        const isDup = seenRects.some((sr) => Math.abs(sr.left - r.left) < 35 && Math.abs(sr.top - r.top) < 35);
        if (!isDup) seenRects.push(r);
      }
    }
    return seenRects.length;
  }

  function checkFlowCreditsExhausted() {
    const exhaustedPhrases = [
      'not enough credits',
      'insufficient credits',
      'out of credits',
      'no credits left',
      'no credits remaining',
      "you don't have enough credits",
      'monthly limit reached',
      'daily limit reached',
      'quota exceeded'
    ];
    const alerts = Array.from(document.querySelectorAll('[role="alert"], [role="status"], .snackbar, .toast, dialog, [role="dialog"], div, span'));
    for (const a of alerts) {
      if (a.children.length > 3) continue;
      const txt = (a.innerText || '').trim().toLowerCase();
      if (!txt || txt.length > 260 || txt.includes('running low')) continue;
      if (exhaustedPhrases.some((p) => txt.includes(p))) return true;
    }
    const rem = getFlowRemainingCredits();
    if (rem !== null && rem === 0) return true;
    return false;
  }

  // Exact detection of the inline "Failed — This prompt might violate our policies..." card shown at 04:07 of Video 2!
  // Also clicks the Trash/Delete icon [🗑️] on the Failed card so it is removed before the next scene!
  function checkAndCleanupFlowFailedCardOrError() {
    if (checkFlowCreditsExhausted()) return '';

    // 1. Check for the inline "Failed" card on the project canvas (Video 2 @ 04:07 - 05:15)
    const allDivs = Array.from(document.querySelectorAll('div, section, article'));
    for (const box of allDivs) {
      const r = box.getBoundingClientRect();
      if (r.width < 180 || r.height < 60 || r.height > 420 || r.top < 35 || r.top > window.innerHeight * 0.80) continue;
      const rawTxt = (box.innerText || '').trim();
      if (!rawTxt || rawTxt.length > 500) continue;
      const lower = rawTxt.toLowerCase();

      if (
        (lower.startsWith('failed') || lower.includes('\nfailed\n')) &&
        (lower.includes('violate') || lower.includes('policies') || lower.includes('refunded') ||
         lower.includes('different prompt') || lower.includes('harmful') || lower.includes('error') ||
         lower.includes('unable') || lower.includes('couldn'))
      ) {
        // Click the Trash/Delete button [🗑️] at the bottom-right of this Failed card so it doesn't stay on canvas!
        const cardBtns = Array.from(box.querySelectorAll('button, [role="button"]')).filter((b) => {
          const br = b.getBoundingClientRect();
          return br.width >= 16 && br.width <= 60 && br.height >= 16 && br.height <= 60;
        }).sort((a, b) => b.getBoundingClientRect().left - a.getBoundingClientRect().left);

        if (cardBtns.length > 0) {
          // The rightmost button inside the Failed card ([↻] [💬] [🗑️]) is the Delete/Trash button!
          dispatchRealClick(cardBtns[cardBtns.length - 1]);
        }

        const firstLine = rawTxt.split('\n').map((l) => l.trim()).filter((l) => l && l.toLowerCase() !== 'failed')[0];
        return firstLine || 'Failed: This prompt might violate Flow AI policies';
      }
    }

    // 2. Check toast / alert popups
    const errorPairs = [
      ['violat', 'Policy Violation (Prompt / Image Restricted)'],
      ['try a different prompt', 'Rejected Video Prompt (Policy Violation)'],
      ['try another prompt', 'Rejected Video Prompt (Policy Violation)'],
      ['try a different image', 'Rejected Uploaded Image'],
      ['cannot upload', 'Image Upload Rejected'],
      ['upload failed', 'Image Upload Failed'],
      ["couldn't generate", 'Could Not Generate Video (Policy / Error)'],
      ['unable to generate', 'Unable to Generate Video (Policy / Error)'],
      ['failed to generate', 'Failed to Generate Video'],
      ['generation failed', 'Generation Failed'],
      ['something went wrong', 'Flow AI Generation Error']
    ];

    const containers = Array.from(document.querySelectorAll('[role="alert"], [role="status"], .snackbar, .toast, [role="dialog"], dialog'));
    for (const el of containers) {
      const txt = (el.innerText || el.textContent || '').trim().toLowerCase();
      if (!txt || txt.length > 350 || txt.includes('running low') || txt.includes('did you request help signing in')) continue;
      for (const [phrase, reason] of errorPairs) {
        if (txt.includes(phrase)) return reason;
      }
    }
    return '';
  }

  async function clearComposerBoxBeforeScene() {
    await ensureOnMainProjectCanvas();
    await dismissAllFlowPopups();

    const composer = findFlowComposerContainer();
    if (!composer) return;
    const cRect = composer.getBoundingClientRect();

    // Click any small '✕' clear/remove buttons inside the top half of the composer box
    const clearBtns = Array.from(composer.querySelectorAll('button, [role="button"]')).filter((b) => {
      const r = b.getBoundingClientRect();
      if (r.width < 12 || r.width > 42 || r.height < 12 || r.height > 42) return false;
      if (r.top > cRect.top + cRect.height * 0.58) return false;
      const t = (b.innerText || b.textContent || '').trim().toLowerCase();
      const aria = (b.getAttribute('aria-label') || b.getAttribute('title') || '').trim().toLowerCase();
      return ['x', '✕', '✖', '×', 'close', 'clear', 'remove', 'delete'].includes(t) ||
        aria.includes('remove') || aria.includes('clear') || aria.includes('delete') || aria.includes('close') ||
        r.width <= 32;
    });

    for (const cb of clearBtns) {
      dispatchRealClick(cb);
      await sleep(250);
    }

    const box = findFlowPromptTextbox();
    if (box) {
      const curTxt = (box.value || box.innerText || box.textContent || '').trim();
      if (curTxt && !curTxt.toLowerCase().includes('what do you want to create')) {
        dispatchRealClick(box);
        if (box.focus) box.focus();
        try {
          document.execCommand('selectAll', false, null);
          document.execCommand('delete', false, null);
        } catch (e) {}
        if (box.tagName === 'TEXTAREA' || box.tagName === 'INPUT') box.value = '';
        else box.textContent = '';
        box.dispatchEvent(new InputEvent('input', { bubbles: true }));
      }
    }
  }

  // Exact Report Format requested by User in Video 2 (04:25 - 05:15):
  // - Includes Account Name + Logged-In Email ID so user knows which Gmail account made which scenes
  // - Scene table with 2 clear outcomes:
  //   * If succeeded -> "Haan ho gaya hai (YES)" and NO reason column
  //   * If failed    -> "Nahi hua hai (NO)" + exact Reason!
  function writeRealtimeFlowReport() {
    if (!bridge || typeof bridge.saveFlowSceneAccountReport !== 'function') return;
    const completedNums = Object.keys(botRuntime.sceneAccountMap).map(Number).sort((a, b) => a - b);
    const droppedNums = botRuntime.skippedScenes.map((x) => x.scene_no).sort((a, b) => a - b);

    const accountsSummary = {};
    completedNums.forEach((sNo) => {
      const acc = botRuntime.sceneAccountMap[sNo];
      if (!accountsSummary[acc]) accountsSummary[acc] = [];
      accountsSummary[acc].push('Scene_' + String(sNo).padStart(2, '0'));
    });

    const lines = [
      '======================================================================================',
      '   ITIHASKAR SAMAY - FLOW AI SCENE & ACCOUNT REPORT (WITH GMAIL ID)',
      '======================================================================================',
      'PDF / Source File          : ' + (botRuntime.sourcePdf || 'Script.pdf'),
      'Date & Time                : ' + new Date().toLocaleString(),
      'Total Scenes Selected      : ' + botRuntime.scenes.length + ' -> [' + botRuntime.scenes.map((s) => s.scene_no).join(', ') + ']',
      'Total Haan Ho Gaya (YES)   : ' + completedNums.length + ' -> [' + completedNums.join(', ') + ']',
      'Total Nahi Hua (NO)        : ' + droppedNums.length + ' -> [' + droppedNums.join(', ') + ']',
      '--------------------------------------------------------------------------------------',
      '   ACCOUNT & EMAIL ID SUMMARY (KIS GMAIL ACCOUNT SE KON-KON SA VIDEO BANA):',
      '--------------------------------------------------------------------------------------'
    ];

    const accKeys = Object.keys(accountsSummary);
    if (accKeys.length > 0) {
      accKeys.forEach((accLabelWithEmail) => {
        const list = accountsSummary[accLabelWithEmail];
        lines.push('   * ' + accLabelWithEmail + ' : ' + list.length + ' Videos -> ' + list.join(', '));
      });
    } else {
      lines.push('   * Abhi tak kisi account se video complete nahi hua.');
    }

    lines.push(
      '',
      '--------------------------------------------------------------------------------------',
      '   SCENE-WISE STATUS TABLE (HO GAYA HAI YA NAHI + ACCOUNT EMAIL + REASON):',
      '--------------------------------------------------------------------------------------',
      '   SCENE      | HO GAYA YA NAHI?         | ACCOUNT (EMAIL ID)               | REASON (AGAR NAHI HUA)',
      '   -----------------------------------------------------------------------------------'
    );

    botRuntime.scenes.forEach((s) => {
      const sNo = s.scene_no;
      const sPad = String(sNo).padStart(2, '0');
      if (botRuntime.sceneAccountMap[sNo]) {
        // User requested: "Agar ho gaya hai toh koi reason nahi likha jayega!"
        lines.push(
          '   Scene_' + sPad + '   | Haan ho gaya hai (YES)   | ' + botRuntime.sceneAccountMap[sNo] + ' | '
        );
      } else {
        const sk = botRuntime.skippedScenes.find((x) => x.scene_no === sNo);
        if (sk) {
          lines.push(
            '   Scene_' + sPad + '   | Nahi hua hai (NO)        | ' + (sk.account || '---') + ' | ' + sk.reason
          );
        } else {
          lines.push(
            '   Scene_' + sPad + '   | Pending...               | ---                              | '
          );
        }
      }
    });

    lines.push('======================================================================================\n');
    bridge.saveFlowSceneAccountReport(botRuntime.sourcePdf || 'Flow_Scenes.pdf', lines.join('\n'));
  }

  async function runSingleFlowVideoScene(scene) {
    const sNo = Number(scene.scene_no);
    const sPad = String(sNo).padStart(2, '0');
    const baseAccLabel = (bridge && typeof bridge.getActiveAccountLabel === 'function')
      ? bridge.getActiveAccountLabel(2)
      : 'Flow_Account_1';

    await enterFlowProject();
    await ensureOnMainProjectCanvas();

    const email = await detectFlowLoggedInEmail();
    const fullAccLabel = email ? (baseAccLabel + ' (' + email + ')') : baseAccLabel;

    if (checkFlowCreditsExhausted()) return 'rate_limit';

    // Clean any leftover text/image or old Failed cards before starting this scene
    checkAndCleanupFlowFailedCardOrError();
    await clearComposerBoxBeforeScene();

    // 1. Upload Scene_XX.png (Top-Right '+' -> 'Upload'), wait for 100%, then attach via Bottom-Left '+' -> Search 'Scene_XX'
    sendHomeLog('Flow AI me Scene_' + sPad + '.png upload aur attach kiya jaa rha h...', 'LIVE');
    const attached = await uploadAndAttachFlowSceneImage(sNo);
    const upErr = checkAndCleanupFlowFailedCardOrError();
    if (!attached || upErr) {
      const reason = upErr || 'Scene_' + sPad + '.png upload ya prompt me attach nahi ho paya';
      botRuntime.skippedScenes.push({
        scene_no: sNo,
        account: fullAccLabel,
        reason: reason,
        video_prompt: scene.video_prompt
      });
      await clearComposerBoxBeforeScene();
      writeRealtimeFlowReport();
      sendHomeLog('⚠️ Flow AI Scene ' + sPad + ' nahi hua (' + reason + '). Agle scene par badh rhe h...', 'warn');
      return 'refused';
    }

    // 2. Check & configure Settings Pill (Video | 16:9 | Omni 3.1 Flash | 720p | 6s | x1)
    await ensureFlowVideoSettingsConfigured();

    // 3. Record state BEFORE clicking Send
    const creditsBefore = getFlowRemainingCredits();
    const videoCardsBefore = countCompletedFlowVideoCards();

    // 4. Type Video Prompt & Click the round '→' Send button next to the Settings Pill
    sendHomeLog('Flow AI me scene' + sPad + ' ka video prompt likh kar Send (→) dabaya jaa rha h...', 'LIVE');
    const sentOk = await typeFlowPromptAndClickSend(scene.video_prompt || scene.image_prompt);
    if (!sentOk) {
      const reason = 'Prompt Send (→) button click nahi ho paya';
      botRuntime.skippedScenes.push({
        scene_no: sNo,
        account: fullAccLabel,
        reason: reason,
        video_prompt: scene.video_prompt
      });
      await clearComposerBoxBeforeScene();
      writeRealtimeFlowReport();
      sendHomeLog('⚠️ Flow AI Scene ' + sPad + ': ' + reason, 'warn');
      return 'refused';
    }

    sendHomeLog(
      'Flow AI me scene' + sPad + ' ka video prompt send ho gya h! Ab 0% se 100% video banne ka wait kar rhe h...',
      'LIVE'
    );

    // 5. Wait and monitor rendering (0% -> 100%) vs inline 'Failed' policy error card (Video 2 @ 02:27 - 04:18)
    await sleep(4000);
    if (checkFlowCreditsExhausted()) return 'rate_limit';

    let detectedErr = '';
    let sawPercentRendering = false;

    for (let tick = 1; tick <= 60; tick++) {
      if (!botRuntime.running) return 'stopped';
      if (checkFlowCreditsExhausted()) return 'rate_limit';

      const errNow = checkAndCleanupFlowFailedCardOrError();
      if (errNow) {
        detectedErr = errNow;
        break;
      }

      const renderingNow = isAnyUploadOrRenderPercentageVisible();
      if (renderingNow) {
        sawPercentRendering = true;
      }

      const videoCardsNow = countCompletedFlowVideoCards();
      // If rendering started (0%..99%) and now % is gone, OR a new completed <video> card appeared:
      if (sawPercentRendering && !renderingNow && tick >= 3) {
        break;
      }
      if (videoCardsNow > videoCardsBefore && !renderingNow && tick >= 3) {
        break;
      }
      // If after ~36 seconds neither rendering % nor a new video card appeared, break
      if (!sawPercentRendering && videoCardsNow <= videoCardsBefore && tick >= 12) {
        break;
      }
      await sleep(3000);
    }

    if (checkFlowCreditsExhausted()) return 'rate_limit';
    await sleep(2500);
    if (!detectedErr) {
      detectedErr = checkAndCleanupFlowFailedCardOrError();
    }

    const creditsAfter = getFlowRemainingCredits();
    const videoCardsAfter = countCompletedFlowVideoCards();

    let videoCreated = false;
    let failReason = detectedErr;

    if (detectedErr) {
      videoCreated = false;
    } else if (videoCardsAfter > videoCardsBefore || sawPercentRendering) {
      videoCreated = true;
    } else if (creditsBefore !== null && creditsAfter !== null && creditsAfter < creditsBefore) {
      videoCreated = true;
    } else {
      videoCreated = false;
      failReason = 'Video nahi bana (Policy Error ya Generation Start Nahi Hua)';
    }

    if (videoCreated) {
      botRuntime.sceneAccountMap[sNo] = fullAccLabel;
      writeRealtimeFlowReport();
      sendHomeLog('✅ scene' + sPad + ' ka video Flow AI me ban gya h! (' + fullAccLabel + ')', 'ok');
      return 'done';
    } else {
      await clearComposerBoxBeforeScene();
      botRuntime.skippedScenes.push({
        scene_no: sNo,
        account: fullAccLabel,
        reason: failReason || 'Failed: Policy Violation / Error',
        video_prompt: scene.video_prompt
      });
      writeRealtimeFlowReport();
      sendHomeLog('⚠️ Flow AI scene' + sPad + ' nahi bana (' + (failReason || 'Policy Error') + '). Agle scene par badh rhe h...', 'warn');
      return 'refused';
    }
  }

  // ============================================================================
  // MASTER AUTOMATION LOOP (HANDLES BOTH BOT 1 CHATGPT & BOT 2 FLOW AI)
  // ============================================================================
  async function runAutomationQueueLoop() {
    if (botRuntime.running) return;

    if (!bridge || typeof bridge.getActiveAutomationQueueJson !== 'function') return;
    let queueObj = null;
    try {
      const raw = bridge.getActiveAutomationQueueJson();
      if (raw && raw.length > 5) queueObj = JSON.parse(raw);
    } catch (e) {}

    if (!queueObj || !queueObj.active || !Array.isArray(queueObj.scenes) || queueObj.scenes.length === 0) {
      return;
    }

    const isFlowPage = location.hostname.includes('labs.google') || location.hostname.includes('flow.google');
    const qBotType = Number(queueObj.botType || 1);
    if ((qBotType === 2 && !isFlowPage) || (qBotType === 1 && isFlowPage)) {
      return;
    }

    botRuntime.running = true;
    botRuntime.botType = qBotType;
    botRuntime.sourcePdf = queueObj.sourcePdf || 'Script.pdf';
    botRuntime.scenes = queueObj.scenes;

    await sleep(1000);

    for (let i = 0; i < botRuntime.scenes.length; i++) {
      if (!botRuntime.running) break;
      const scene = botRuntime.scenes[i];
      if (scene.status === 'done') continue;

      let result = 'error';
      try {
        result = (botRuntime.botType === 2)
          ? await runSingleFlowVideoScene(scene)
          : await runSingleChatGptScene(scene);
      } catch (err) {
        sendHomeLog('Scene ' + scene.scene_no + ' Note: ' + err.message + ' — retrying in 2s...', 'warn');
        await sleep(2000);
        i -= 1;
        continue;
      }

      if (result === 'stopped') {
        break;
      }

      if (result === 'rate_limit') {
        botRuntime.running = false;
        sendHomeLog('⚠️ Is account me limit/credits khatam ho gye h! Next account apne aap login kiya jaa rha h...', 'warn');
        if (bridge && typeof bridge.switchToNextAccountOnLimit === 'function') {
          const sw = bridge.switchToNextAccountOnLimit(botRuntime.botType);
          if (sw === 'NO_MORE_ACCOUNTS') {
            sendHomeLog('🛑 Saare saved accounts ki limit khatam ho chuki h! Home page se Option 3 (Limits Reset) chunein.', 'BATCH_DONE');
            if (bridge.clearActiveAutomationQueue) bridge.clearActiveAutomationQueue();
          }
        }
        return;
      }

      if (result === 'done' || result === 'refused' || result === 'timeout') {
        scene.status = 'done';
        if (bridge && typeof bridge.updateActiveAutomationQueueJson === 'function') {
          bridge.updateActiveAutomationQueueJson(JSON.stringify(queueObj));
        }
      }

      await sleep(700);
    }

    if (botRuntime.running) {
      botRuntime.running = false;
      if (bridge && typeof bridge.clearActiveAutomationQueue === 'function') {
        bridge.clearActiveAutomationQueue();
      }
      if (botRuntime.botType === 2) {
        writeRealtimeFlowReport();
        sendHomeLog('🎉 Flow AI ke saare requested scenes process ho gye aur Report scene_account_reports folder me save ho gyi!', 'BATCH_DONE');
      } else {
        sendHomeLog('🎉 Saare requested scenes ki images download ho kar output_images folder me save ho gyi hain!', 'BATCH_DONE');
      }
    }
  }

  window.__ITK_START_QUEUE_NOW__ = function () {
    runAutomationQueueLoop();
  };

  window.__ITK_STOP_QUEUE_NOW__ = function () {
    botRuntime.running = false;
  };

  function mountMinimalBottomStatusPill() {
    if (document.getElementById('itk-bottom-bar') || !document.body) return;
    const bar = document.createElement('div');
    bar.id = 'itk-bottom-bar';
    bar.style.cssText =
      'position:fixed;bottom:8px;right:8px;z-index:2147483640;background:rgba(13,17,23,0.92);border:1px solid rgba(255,138,31,0.45);border-radius:999px;padding:5px 12px;color:#a7f3d0;font-family:ui-monospace,monospace;font-size:11px;box-shadow:0 6px 20px rgba(0,0,0,0.6);pointer-events:none;max-width:92vw;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;';
    bar.innerHTML = '<span style="color:#ff8a1f;font-weight:700;">⚡ Fluid Studio: </span><span id="itk-live-pill-text">Ready</span>';
    document.body.appendChild(bar);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', mountMinimalBottomStatusPill);
  } else {
    mountMinimalBottomStatusPill();
  }

  setTimeout(() => {
    if (bridge && typeof bridge.isAutomationCurrentlyActive === 'function' && bridge.isAutomationCurrentlyActive()) {
      runAutomationQueueLoop();
    }
  }, 1200);
})();
